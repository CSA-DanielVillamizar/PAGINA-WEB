"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GalleryService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const gallery_entity_1 = require("./gallery.entity");
const blob_service_1 = require("../../services/blob.service");
/**
 * Servicio de galería.
 * Gestiona álbumes fotográficos: paginación, carga masiva de imágenes,
 * generación de thumbnails y estadísticas.
 */
let GalleryService = class GalleryService {
    constructor(repo, blob) {
        this.repo = repo;
        this.blob = blob;
    }
    /**
     * Listado paginado y filtrado de álbumes.
     */
    async findAll(options) {
        const page = Math.max(options.page || 1, 1);
        const pageSize = Math.min(Math.max(options.pageSize || 10, 1), 100);
        const qb = this.repo.createQueryBuilder('g').orderBy('g.fecha', 'DESC');
        if (options.eventoId)
            qb.andWhere('g.eventoId = :eventoId', { eventoId: options.eventoId });
        if (options.search) {
            qb.andWhere('(g.titulo ILIKE :s OR g.descripcion ILIKE :s)', { s: `%${options.search}%` });
        }
        qb.skip((page - 1) * pageSize).take(pageSize);
        const [items, total] = await qb.getManyAndCount();
        return { items, total, page, pageSize };
    }
    async findOne(id) {
        const album = await this.repo.findOne({ where: { id } });
        if (!album)
            throw new common_1.NotFoundException('Álbum no encontrado');
        return album;
    }
    async create(dto) {
        const album = this.repo.create({
            ...dto,
            fecha: new Date(dto.fecha),
            imagenes: []
        });
        return this.repo.save(album);
    }
    async update(id, dto) {
        const album = await this.findOne(id);
        const updated = { ...dto };
        if (dto.fecha) {
            updated.fecha = new Date(dto.fecha);
        }
        await this.repo.update(id, updated);
        return this.findOne(id);
    }
    async delete(id) {
        const album = await this.findOne(id);
        await this.repo.delete(album.id);
        return { ok: true };
    }
    /**
     * Carga masiva de imágenes al álbum.
     */
    async bulkUploadImages(id, files) {
        const album = await this.findOne(id);
        if (!files || files.length === 0) {
            throw new common_1.BadRequestException('No se recibieron archivos');
        }
        const stored = [];
        for (const file of files) {
            const key = `gallery/${id}/${Date.now()}-${file.originalname}`;
            const url = await this.blob.uploadFile(key, file.buffer, file.mimetype);
            stored.push(url);
        }
        const imagenes = [...album.imagenes, ...stored];
        await this.repo.update(id, { imagenes });
        // Si no hay thumbnail, usar la primera imagen subida
        if (!album.thumbnailUrl && stored.length > 0) {
            await this.repo.update(id, { thumbnailUrl: stored[0] });
        }
        return this.findOne(id);
    }
    /**
     * Agregar una sola imagen al álbum.
     */
    async addImage(id, imageUrl) {
        const album = await this.findOne(id);
        const imagenes = [...album.imagenes, imageUrl];
        await this.repo.update(id, { imagenes });
        return this.findOne(id);
    }
    /**
     * Establecer thumbnail del álbum.
     */
    async setThumbnail(id, file) {
        const album = await this.findOne(id);
        if (!file)
            throw new common_1.BadRequestException('Archivo no recibido');
        const key = `gallery/${id}/thumbnail-${Date.now()}-${file.originalname}`;
        const url = await this.blob.uploadFile(key, file.buffer, file.mimetype);
        await this.repo.update(id, { thumbnailUrl: url });
        return this.findOne(id);
    }
    /**
     * Eliminar imagen del álbum por índice.
     */
    async removeImage(id, index) {
        const album = await this.findOne(id);
        if (index < 0 || index >= album.imagenes.length) {
            throw new common_1.BadRequestException('Índice de imagen inválido');
        }
        const imagenes = album.imagenes.filter((_, i) => i !== index);
        await this.repo.update(id, { imagenes });
        return this.findOne(id);
    }
    /**
     * Estadísticas de galería.
     */
    async stats() {
        const total = await this.repo.count();
        const totalImages = await this.repo
            .createQueryBuilder('g')
            .select('SUM(jsonb_array_length(g.imagenes))', 'count')
            .getRawOne();
        const recent = await this.repo.find({ order: { createdAt: 'DESC' }, take: 5 });
        return {
            totalAlbums: total,
            totalImages: parseInt(totalImages.count || '0'),
            recent
        };
    }
};
exports.GalleryService = GalleryService;
exports.GalleryService = GalleryService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(gallery_entity_1.GalleryAlbum)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        blob_service_1.BlobService])
], GalleryService);
//# sourceMappingURL=gallery.service.js.map