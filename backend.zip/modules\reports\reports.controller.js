"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportsController = void 0;
const common_1 = require("@nestjs/common");
const reports_service_1 = require("./reports.service");
const jwt_auth_guard_1 = require("../../guards/jwt-auth.guard");
const roles_guard_1 = require("../../guards/roles.guard");
const roles_decorator_1 = require("../../decorators/roles.decorator");
const swagger_1 = require("@nestjs/swagger");
/**
 * Controlador para generación de reportes.
 * Todos los endpoints requieren autenticación y roles administrativos.
 */
let ReportsController = class ReportsController {
    constructor(reportsService) {
        this.reportsService = reportsService;
    }
    /**
     * Genera un reporte de usuarios en CSV o PDF
     */
    async getUsersReport(format, res) {
        if (format === 'pdf') {
            const buffer = await this.reportsService.generateUsersPDF();
            res.set({
                'Content-Type': 'application/pdf',
                'Content-Disposition': `attachment; filename="usuarios_${Date.now()}.pdf"`,
            });
            res.send(buffer);
        }
        else {
            const buffer = await this.reportsService.generateUsersCSV();
            res.set({
                'Content-Type': 'text/csv',
                'Content-Disposition': `attachment; filename="usuarios_${Date.now()}.csv"`,
            });
            res.send(buffer);
        }
    }
    /**
     * Genera un reporte de miembros en CSV
     */
    async getMembersReport(format, res) {
        const buffer = await this.reportsService.generateMembersCSV();
        res.set({
            'Content-Type': 'text/csv',
            'Content-Disposition': `attachment; filename="miembros_${Date.now()}.csv"`,
        });
        res.send(buffer);
    }
    /**
     * Genera un reporte de eventos en CSV
     */
    async getEventsReport(format, res) {
        const buffer = await this.reportsService.generateEventsCSV();
        res.set({
            'Content-Type': 'text/csv',
            'Content-Disposition': `attachment; filename="eventos_${Date.now()}.csv"`,
        });
        res.send(buffer);
    }
    /**
     * Genera un reporte de donaciones en CSV o PDF
     */
    async getDonationsReport(format, res) {
        if (format === 'pdf') {
            const buffer = await this.reportsService.generateDonationsPDF();
            res.set({
                'Content-Type': 'application/pdf',
                'Content-Disposition': `attachment; filename="donaciones_${Date.now()}.pdf"`,
            });
            res.send(buffer);
        }
        else {
            const buffer = await this.reportsService.generateDonationsCSV();
            res.set({
                'Content-Type': 'text/csv',
                'Content-Disposition': `attachment; filename="donaciones_${Date.now()}.csv"`,
            });
            res.send(buffer);
        }
    }
    /**
     * Genera un reporte de inventario de souvenirs en CSV
     */
    async getSouvenirsReport(format, res) {
        const buffer = await this.reportsService.generateSouvenirsCSV();
        res.set({
            'Content-Type': 'text/csv',
            'Content-Disposition': `attachment; filename="inventario_${Date.now()}.csv"`,
        });
        res.send(buffer);
    }
    /**
     * Genera un reporte de suscriptores en CSV
     */
    async getSubscriptionsReport(format, res) {
        const buffer = await this.reportsService.generateSubscriptionsCSV();
        res.set({
            'Content-Type': 'text/csv',
            'Content-Disposition': `attachment; filename="suscriptores_${Date.now()}.csv"`,
        });
        res.send(buffer);
    }
};
exports.ReportsController = ReportsController;
__decorate([
    (0, common_1.Get)('users'),
    (0, roles_decorator_1.Roles)('Administrador', 'Presidente', 'Vicepresidente'),
    (0, swagger_1.ApiOperation)({ summary: 'Generar reporte de usuarios' }),
    (0, swagger_1.ApiQuery)({ name: 'format', enum: ['csv', 'pdf'] }),
    __param(0, (0, common_1.Query)('format')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getUsersReport", null);
__decorate([
    (0, common_1.Get)('members'),
    (0, roles_decorator_1.Roles)('Administrador', 'Presidente', 'Secretario'),
    (0, swagger_1.ApiOperation)({ summary: 'Generar reporte de miembros' }),
    (0, swagger_1.ApiQuery)({ name: 'format', enum: ['csv', 'pdf'] }),
    __param(0, (0, common_1.Query)('format')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getMembersReport", null);
__decorate([
    (0, common_1.Get)('events'),
    (0, roles_decorator_1.Roles)('Administrador', 'Presidente', 'MTO'),
    (0, swagger_1.ApiOperation)({ summary: 'Generar reporte de eventos' }),
    (0, swagger_1.ApiQuery)({ name: 'format', enum: ['csv', 'pdf'] }),
    __param(0, (0, common_1.Query)('format')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getEventsReport", null);
__decorate([
    (0, common_1.Get)('donations'),
    (0, roles_decorator_1.Roles)('Administrador', 'Presidente', 'Tesorero'),
    (0, swagger_1.ApiOperation)({ summary: 'Generar reporte de donaciones' }),
    (0, swagger_1.ApiQuery)({ name: 'format', enum: ['csv', 'pdf'] }),
    __param(0, (0, common_1.Query)('format')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getDonationsReport", null);
__decorate([
    (0, common_1.Get)('souvenirs'),
    (0, roles_decorator_1.Roles)('Administrador', 'GerenciaNegocios'),
    (0, swagger_1.ApiOperation)({ summary: 'Generar reporte de inventario' }),
    (0, swagger_1.ApiQuery)({ name: 'format', enum: ['csv', 'pdf'] }),
    __param(0, (0, common_1.Query)('format')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getSouvenirsReport", null);
__decorate([
    (0, common_1.Get)('subscriptions'),
    (0, roles_decorator_1.Roles)('Administrador', 'CommunityManager'),
    (0, swagger_1.ApiOperation)({ summary: 'Generar reporte de suscriptores' }),
    (0, swagger_1.ApiQuery)({ name: 'format', enum: ['csv', 'pdf'] }),
    __param(0, (0, common_1.Query)('format')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getSubscriptionsReport", null);
exports.ReportsController = ReportsController = __decorate([
    (0, swagger_1.ApiTags)('Reports'),
    (0, common_1.Controller)('reports'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [reports_service_1.ReportsService])
], ReportsController);
//# sourceMappingURL=reports.controller.js.map