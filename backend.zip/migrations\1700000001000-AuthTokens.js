"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthTokens1700000001000 = void 0;
/**
 * Migration: creación de tablas para tokens de autenticación (confirmación email, reset password, refresh tokens).
 */
class AuthTokens1700000001000 {
    constructor() {
        this.name = 'AuthTokens1700000001000';
    }
    async up(queryRunner) {
        await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "email_confirmation_tokens" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "tokenHash" varchar(128) UNIQUE NOT NULL,
        "expiresAt" timestamptz NOT NULL,
        "used" boolean NOT NULL DEFAULT false,
        "userId" uuid NOT NULL,
        "createdAt" timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT "fk_email_conf_user" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE
      );
    `);
        await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "password_reset_tokens" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "tokenHash" varchar(128) UNIQUE NOT NULL,
        "expiresAt" timestamptz NOT NULL,
        "used" boolean NOT NULL DEFAULT false,
        "userId" uuid NOT NULL,
        "createdAt" timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT "fk_pwd_reset_user" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE
      );
    `);
        await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "refresh_tokens" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "tokenHash" varchar(128) UNIQUE NOT NULL,
        "expiresAt" timestamptz NOT NULL,
        "revoked" boolean NOT NULL DEFAULT false,
        "userId" uuid NOT NULL,
        "createdAt" timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT "fk_refresh_user" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE
      );
    `);
    }
    async down(queryRunner) {
        await queryRunner.query('DROP TABLE IF EXISTS "refresh_tokens"');
        await queryRunner.query('DROP TABLE IF EXISTS "password_reset_tokens"');
        await queryRunner.query('DROP TABLE IF EXISTS "email_confirmation_tokens"');
    }
}
exports.AuthTokens1700000001000 = AuthTokens1700000001000;
//# sourceMappingURL=1700000001000-AuthTokens.js.map