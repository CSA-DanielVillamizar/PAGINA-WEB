"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionEnhancements1700000007000 = void 0;
const typeorm_1 = require("typeorm");
class SubscriptionEnhancements1700000007000 {
    async up(queryRunner) {
        await queryRunner.addColumn('subscriptions', new typeorm_1.TableColumn({
            name: 'confirmToken',
            type: 'uuid',
            isNullable: true,
            isUnique: true,
            comment: 'Token único para confirmación de email'
        }));
        await queryRunner.addColumn('subscriptions', new typeorm_1.TableColumn({
            name: 'unsubscribeToken',
            type: 'uuid',
            isNullable: true,
            isUnique: true,
            comment: 'Token único para desuscripción directa sin login'
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('subscriptions', 'unsubscribeToken');
        await queryRunner.dropColumn('subscriptions', 'confirmToken');
    }
}
exports.SubscriptionEnhancements1700000007000 = SubscriptionEnhancements1700000007000;
//# sourceMappingURL=1700000007000-SubscriptionEnhancements.js.map