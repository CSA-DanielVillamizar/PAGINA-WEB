"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const common_1 = require("@nestjs/common");
const auth_service_1 = require("./auth.service");
const jwt_1 = require("@nestjs/jwt");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const user_entity_1 = require("../users/user.entity");
const jwt_auth_guard_1 = require("../../guards/jwt-auth.guard");
const current_user_decorator_1 = require("../../decorators/current-user.decorator");
const swagger_1 = require("@nestjs/swagger");
/**
 * Controlador de autenticación con Microsoft Entra ID multi-tenant.
 * Permite usuarios de dominio externo y marca flag external en payload.
 */
let AuthController = class AuthController {
    constructor(authService, jwtService, usersRepository) {
        this.authService = authService;
        this.jwtService = jwtService;
        this.usersRepository = usersRepository;
    }
    async getLoginUrl() {
        const url = await this.authService.getAuthorizationUrl();
        return { url };
    }
    async callback(code) {
        if (!code)
            throw new common_1.BadRequestException('Falta parámetro code');
        const msalResponse = await this.authService.acquireTokenByCode(code);
        const azureUser = await this.authService.validateAzureToken(msalResponse.accessToken);
        let user = await this.usersRepository.findOne({
            where: { correo: azureUser.email },
            relations: ['roles'],
        });
        if (!user) {
            user = this.usersRepository.create({
                correo: azureUser.email,
                nombreCompleto: azureUser.name,
                estado: 'ACTIVE'
            });
            user = await this.usersRepository.save(user);
        }
        const payload = {
            sub: user.id,
            email: user.correo,
            roles: user.roles?.map(r => r.name) || [],
            external: azureUser.external
        };
        const accessToken = this.jwtService.sign(payload);
        return {
            accessToken,
            user: {
                id: user.id,
                nombreCompleto: user.nombreCompleto,
                correo: user.correo,
                roles: user.roles,
                external: azureUser.external
            }
        };
    }
    // ---------------------- NUEVOS ENDPOINTS AUTENTICACIÓN LOCAL ----------------------
    async register(body) {
        const { email, password, fullName } = body;
        if (!email || !password || !fullName)
            throw new common_1.BadRequestException('email, password y fullName son requeridos');
        return this.authService.register(email, password, fullName);
    }
    async confirmEmail(token) {
        if (!token)
            throw new common_1.BadRequestException('Falta token');
        return this.authService.confirmEmail(token);
    }
    async login(body) {
        const { email, password } = body;
        if (!email || !password)
            throw new common_1.BadRequestException('email y password requeridos');
        return this.authService.loginLocal(email, password);
    }
    async refresh(refreshToken) {
        if (!refreshToken)
            throw new common_1.BadRequestException('Falta refreshToken');
        return this.authService.refresh(refreshToken);
    }
    async forgotPassword(email) {
        if (!email)
            throw new common_1.BadRequestException('Falta email');
        return this.authService.forgotPassword(email);
    }
    async resetPassword(body) {
        const { token, newPassword } = body;
        if (!token || !newPassword)
            throw new common_1.BadRequestException('token y newPassword requeridos');
        return this.authService.resetPassword(token, newPassword);
    }
    async getCurrentUser(user) {
        return {
            id: user.id,
            nombreCompleto: user.nombreCompleto,
            correo: user.correo,
            roles: user.roles,
        };
    }
};
exports.AuthController = AuthController;
__decorate([
    (0, common_1.Get)('login-url'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener URL de login de Microsoft (multi-tenant)' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "getLoginUrl", null);
__decorate([
    (0, common_1.Post)('callback'),
    (0, swagger_1.ApiOperation)({ summary: 'Callback OAuth2 Microsoft: intercambio code por token' }),
    __param(0, (0, common_1.Body)('code')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "callback", null);
__decorate([
    (0, common_1.Post)('register'),
    (0, swagger_1.ApiOperation)({ summary: 'Registro de usuario local con confirmación de email' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "register", null);
__decorate([
    (0, common_1.Post)('confirm-email'),
    (0, swagger_1.ApiOperation)({ summary: 'Confirmar email con token' }),
    __param(0, (0, common_1.Body)('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "confirmEmail", null);
__decorate([
    (0, common_1.Post)('login'),
    (0, swagger_1.ApiOperation)({ summary: 'Login local con email y password' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "login", null);
__decorate([
    (0, common_1.Post)('refresh'),
    (0, swagger_1.ApiOperation)({ summary: 'Refrescar sesión con refresh token' }),
    __param(0, (0, common_1.Body)('refreshToken')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "refresh", null);
__decorate([
    (0, common_1.Post)('forgot-password'),
    (0, swagger_1.ApiOperation)({ summary: 'Solicitar recuperación de contraseña' }),
    __param(0, (0, common_1.Body)('email')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "forgotPassword", null);
__decorate([
    (0, common_1.Post)('reset-password'),
    (0, swagger_1.ApiOperation)({ summary: 'Restablecer contraseña mediante token' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "resetPassword", null);
__decorate([
    (0, common_1.Get)('me'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Usuario actual y sus roles' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "getCurrentUser", null);
exports.AuthController = AuthController = __decorate([
    (0, swagger_1.ApiTags)('Auth'),
    (0, common_1.Controller)('auth'),
    __param(2, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [auth_service_1.AuthService,
        jwt_1.JwtService,
        typeorm_2.Repository])
], AuthController);
//# sourceMappingURL=auth.controller.js.map