"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Script manual para inicialización de la conexión y ejecución opcional de migraciones.
 * Uso: npm run build && npm run db:init
 * No se ejecuta en el arranque automático para evitar bloquear el cold start.
 */
const database_provider_1 = require("../database/database.provider");
async function run() {
    console.log('[db:init] Inicializando DataSource...');
    const start = Date.now();
    await (0, database_provider_1.ensureDatabaseInitialized)();
    const status = (0, database_provider_1.getDatabaseStatus)();
    const elapsed = Date.now() - start;
    console.log(`[db:init] Estado: ${status} (elapsed ${elapsed}ms)`);
    if (status === 'error') {
        console.error('[db:init] Error:', (0, database_provider_1.getDatabaseError)()?.message);
        process.exit(1);
    }
    if (status === 'connected') {
        // Ejecutar migraciones manualmente si se requiere.
        console.log('[db:init] Ejecutando migraciones (manual)...');
        try {
            // Import dinámico del runner compilado.
            const { runMigrations } = await Promise.resolve().then(() => __importStar(require('./migrations-runner-wrapper')));
            await runMigrations(database_provider_1.AppDataSource);
            console.log('[db:init] Migraciones completadas.');
        }
        catch (err) {
            console.warn('[db:init] No se encontró wrapper de migraciones o falló la ejecución:', err.message);
        }
    }
}
run().catch(err => {
    console.error('[db:init] Fallo inesperado:', err);
    process.exit(1);
});
//# sourceMappingURL=db-init.js.map