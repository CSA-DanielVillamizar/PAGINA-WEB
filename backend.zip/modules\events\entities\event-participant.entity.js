"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventParticipant = exports.RegistrationSource = exports.ParticipantStatus = void 0;
const typeorm_1 = require("typeorm");
const event_entity_1 = require("./event.entity");
const user_entity_1 = require("../../users/user.entity");
/**
 * Estado de la participación
 */
var ParticipantStatus;
(function (ParticipantStatus) {
    ParticipantStatus["REGISTRADO"] = "REGISTRADO";
    ParticipantStatus["CONFIRMADO"] = "CONFIRMADO";
    ParticipantStatus["ASISTIO"] = "ASISTIO";
    ParticipantStatus["NO_ASISTIO"] = "NO_ASISTIO";
})(ParticipantStatus || (exports.ParticipantStatus = ParticipantStatus = {}));
/**
 * Fuente de registro
 */
var RegistrationSource;
(function (RegistrationSource) {
    RegistrationSource["WEB"] = "WEB";
    RegistrationSource["APP"] = "APP";
    RegistrationSource["ADMIN"] = "ADMIN";
})(RegistrationSource || (exports.RegistrationSource = RegistrationSource = {}));
/**
 * Entidad EventParticipant - Representa la participación de un miembro en un evento
 * Registra asistencia, fuente de inscripción y estado
 */
let EventParticipant = class EventParticipant {
};
exports.EventParticipant = EventParticipant;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], EventParticipant.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid' }),
    __metadata("design:type", String)
], EventParticipant.prototype, "eventId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => event_entity_1.Event, event => event.participantes, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'eventId' }),
    __metadata("design:type", event_entity_1.Event)
], EventParticipant.prototype, "event", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid' }),
    __metadata("design:type", String)
], EventParticipant.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.User, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'userId' }),
    __metadata("design:type", user_entity_1.User)
], EventParticipant.prototype, "user", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)(),
    __metadata("design:type", Date)
], EventParticipant.prototype, "fechaRegistro", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: RegistrationSource,
        default: RegistrationSource.WEB
    }),
    __metadata("design:type", String)
], EventParticipant.prototype, "fuente", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: ParticipantStatus,
        default: ParticipantStatus.REGISTRADO
    }),
    __metadata("design:type", String)
], EventParticipant.prototype, "estado", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], EventParticipant.prototype, "notas", void 0);
exports.EventParticipant = EventParticipant = __decorate([
    (0, typeorm_1.Entity)('event_participants')
], EventParticipant);
//# sourceMappingURL=event-participant.entity.js.map