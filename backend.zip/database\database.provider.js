"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppDataSource = void 0;
exports.ensureDatabaseInitialized = ensureDatabaseInitialized;
exports.getDatabaseStatus = getDatabaseStatus;
exports.getDatabaseError = getDatabaseError;
require("reflect-metadata");
const typeorm_1 = require("typeorm");
/**
 * Proveedor único del DataSource de la aplicación.
 * Implementa INITIALIZACIÓN LAZY: no se llama a initialize() durante el bootstrap
 * de NestJS para evitar bloquear el arranque en Azure App Service.
 * Se inicializa después de que el servidor HTTP comienza a escuchar.
 */
exports.AppDataSource = new typeorm_1.DataSource({
    type: 'postgres',
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT || '5432', 10),
    username: process.env.DB_USER,
    password: process.env.DB_PASS || process.env.DB_PASSWORD,
    database: process.env.DB_NAME || 'lama_db',
    // Patrón de entidades compiladas en dist (producción). En desarrollo se puede ajustar.
    entities: [process.cwd() + '/dist/**/**/*.entity.js'],
    synchronize: false, // Nunca en producción. Migraciones manuales.
    logging: ['error', 'warn'],
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    extra: {
        max: 2, // Pool mínimo para reducir overhead en cold start
        connectionTimeoutMillis: 30000
    }
});
// Estado interno de la conexión para reportar en health sin bloquear.
let dbError = null;
/**
 * Inicializa el DataSource si aún no está inicializado.
 * No lanza excepción: captura y almacena el error para health endpoint.
 */
async function ensureDatabaseInitialized() {
    if (process.env.DISABLE_DB === '1')
        return;
    if (exports.AppDataSource.isInitialized)
        return;
    try {
        await exports.AppDataSource.initialize();
    }
    catch (err) {
        dbError = err;
    }
}
/**
 * Obtiene el estado textual de la base de datos para endpoints de salud.
 */
function getDatabaseStatus() {
    if (process.env.DISABLE_DB === '1')
        return 'pending';
    if (exports.AppDataSource.isInitialized)
        return 'connected';
    return dbError ? 'error' : 'pending';
}
/**
 * Retorna el último error capturado (si existe) para diagnósticos.
 */
function getDatabaseError() {
    return dbError;
}
//# sourceMappingURL=database.provider.js.map