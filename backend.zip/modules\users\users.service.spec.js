"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const testing_1 = require("@nestjs/testing");
const users_service_1 = require("./users.service");
const typeorm_1 = require("@nestjs/typeorm");
const user_entity_1 = require("./user.entity");
const role_entity_1 = require("../roles/role.entity");
const bcrypt = __importStar(require("bcrypt"));
describe('UsersService', () => {
    let service;
    const users = [];
    const roles = [];
    const userRepoMock = {
        find: jest.fn(async () => users),
        findOne: jest.fn(async ({ where: { id } }) => users.find(u => u.id === id)),
        create: jest.fn((data) => ({ ...data })),
        save: jest.fn(async (u) => { users.push(u); return u; })
    };
    const roleRepoMock = {
        find: jest.fn(async ({ where }) => {
            return where.map((w) => ({ id: w.name + '-id', name: w.name }));
        })
    };
    beforeAll(async () => {
        const module = await testing_1.Test.createTestingModule({
            providers: [
                users_service_1.UsersService,
                { provide: (0, typeorm_1.getRepositoryToken)(user_entity_1.User), useValue: userRepoMock },
                { provide: (0, typeorm_1.getRepositoryToken)(role_entity_1.Role), useValue: roleRepoMock }
            ]
        }).compile();
        service = module.get(users_service_1.UsersService);
    });
    it('debe crear usuario con password hasheado y roles', async () => {
        const dto = { nombreCompleto: 'Juan Perez', correo: 'juan@example.com', password: 'Password123', roles: ['Administrador'] };
        const created = await service.create(dto);
        expect(created.passwordHash).toBeDefined();
        expect(await bcrypt.compare('Password123', created.passwordHash)).toBe(true);
        expect(created.roles[0].name).toBe('Administrador');
    });
    it('debe listar usuarios', async () => {
        const all = await service.findAll();
        expect(all.length).toBeGreaterThan(0);
    });
});
//# sourceMappingURL=users.service.spec.js.map