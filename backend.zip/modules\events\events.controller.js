"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventsController = void 0;
const common_1 = require("@nestjs/common");
const events_service_1 = require("./events.service");
const create_event_dto_1 = require("./dto/create-event.dto");
const update_event_dto_1 = require("./dto/update-event.dto");
const register_event_dto_1 = require("./dto/register-event.dto");
const update_participant_status_dto_1 = require("./dto/update-participant-status.dto");
const jwt_auth_guard_1 = require("../../guards/jwt-auth.guard");
const roles_guard_1 = require("../../guards/roles.guard");
const roles_decorator_1 = require("../../decorators/roles.decorator");
const current_user_decorator_1 = require("../../decorators/current-user.decorator");
const event_entity_1 = require("./entities/event.entity");
/**
 * Controller de eventos
 * Rutas públicas (GET) y protegidas (POST/PUT/DELETE - solo Junta)
 */
let EventsController = class EventsController {
    constructor(eventsService) {
        this.eventsService = eventsService;
    }
    /**
     * Listar todos los eventos con filtros
     * Público - cualquiera puede ver eventos
     */
    async findAll(tipo, estado, desde, hasta) {
        return this.eventsService.findAll({ tipo, estado, desde, hasta });
    }
    /**
     * Obtener evento por slug (para URLs amigables)
     * Público
     */
    async findBySlug(slug) {
        return this.eventsService.findBySlug(slug);
    }
    /**
     * Obtener evento por ID
     * Público
     */
    async findOne(id) {
        return this.eventsService.findOne(id);
    }
    /**
     * Crear nuevo evento
     * Solo Presidente, Vicepresidente, Secretario, Tesorero, MTO, Negocios, Admin
     */
    async create(createEventDto) {
        return this.eventsService.create(createEventDto);
    }
    /**
     * Actualizar evento existente
     * Solo roles de Junta + MTO + Negocios
     */
    async update(id, updateEventDto) {
        return this.eventsService.update(id, updateEventDto);
    }
    /**
     * Eliminar evento
     * Solo Presidente, Vicepresidente y Admin
     */
    async remove(id) {
        await this.eventsService.remove(id);
        return { message: 'Evento eliminado exitosamente' };
    }
    /**
     * Inscribirse a un evento
     * Requiere autenticación - solo miembros del capítulo
     */
    async registerToEvent(eventId, user, registerDto) {
        return this.eventsService.registerParticipant(eventId, user.id, registerDto);
    }
    /**
     * Cancelar inscripción a un evento
     * Requiere autenticación
     */
    async cancelRegistration(eventId, user) {
        await this.eventsService.cancelRegistration(eventId, user.id);
        return { message: 'Inscripción cancelada exitosamente' };
    }
    /**
     * Verificar si usuario está inscrito
     * Requiere autenticación
     */
    async checkMyRegistration(eventId, user) {
        const isRegistered = await this.eventsService.isUserRegistered(eventId, user.id);
        return { isRegistered };
    }
    /**
     * Obtener participantes de un evento
     * Público (pero con info limitada) o completo para admin
     */
    async getParticipants(eventId) {
        return this.eventsService.getEventParticipants(eventId);
    }
    /**
     * Obtener estadísticas de un evento
     * Público
     */
    async getEventStats(eventId) {
        return this.eventsService.getEventStats(eventId);
    }
    /**
     * Actualizar estado de participación
     * Solo roles de Junta - para marcar asistencia
     */
    async updateParticipantStatus(updateDto) {
        return this.eventsService.updateParticipantStatus(updateDto);
    }
    /**
     * Ranking de asistencia anual
     * Público - celebramos a nuestros riders más activos
     */
    async getRanking(year) {
        return this.eventsService.getRankingAnual(year);
    }
    /**
     * Estadísticas individuales de un miembro
     * Requiere autenticación
     */
    async getMyStats(user, year) {
        return this.eventsService.getMemberStats(user.id, year);
    }
};
exports.EventsController = EventsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('tipo')),
    __param(1, (0, common_1.Query)('estado')),
    __param(2, (0, common_1.Query)('desde')),
    __param(3, (0, common_1.Query)('hasta')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('slug/:slug'),
    __param(0, (0, common_1.Param)('slug')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "findBySlug", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)('Presidente', 'Vicepresidente', 'Secretario', 'Tesorero', 'MTO', 'Negocios', 'Admin'),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true, whitelist: true }))),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_event_dto_1.CreateEventDto]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)('Presidente', 'Vicepresidente', 'Secretario', 'Tesorero', 'MTO', 'Negocios', 'Admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true, whitelist: true }))),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_event_dto_1.UpdateEventDto]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)('Presidente', 'Vicepresidente', 'Admin'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "remove", null);
__decorate([
    (0, common_1.Post)(':id/inscribirse'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true, whitelist: true }))),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, register_event_dto_1.RegisterEventDto]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "registerToEvent", null);
__decorate([
    (0, common_1.Delete)(':id/cancelar-inscripcion'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "cancelRegistration", null);
__decorate([
    (0, common_1.Get)(':id/mi-inscripcion'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "checkMyRegistration", null);
__decorate([
    (0, common_1.Get)(':id/participantes'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "getParticipants", null);
__decorate([
    (0, common_1.Get)(':id/stats'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "getEventStats", null);
__decorate([
    (0, common_1.Put)('participantes/estado'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)('Presidente', 'Vicepresidente', 'Secretario', 'Tesorero', 'MTO', 'Admin'),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true, whitelist: true }))),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [update_participant_status_dto_1.UpdateParticipantStatusDto]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "updateParticipantStatus", null);
__decorate([
    (0, common_1.Get)('ranking/asistencia'),
    __param(0, (0, common_1.Query)('year', new common_1.DefaultValuePipe(new Date().getFullYear()), common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "getRanking", null);
__decorate([
    (0, common_1.Get)('ranking/mis-estadisticas'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('year', new common_1.DefaultValuePipe(new Date().getFullYear()), common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Number]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "getMyStats", null);
exports.EventsController = EventsController = __decorate([
    (0, common_1.Controller)('events'),
    __metadata("design:paramtypes", [events_service_1.EventsService])
], EventsController);
//# sourceMappingURL=events.controller.js.map