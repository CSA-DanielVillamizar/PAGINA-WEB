"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventPointsRules = void 0;
const event_entity_1 = require("../entities/event.entity");
/**
 * Reglas oficiales de puntuación de la Fundación L.A.M.A. Medellín
 * Puntos por tipo de actividad según reglamento interno
 */
class EventPointsRules {
    /**
     * Obtener puntos por tipo de actividad
     */
    static getPoints(tipo) {
        return this.POINTS_MAP[tipo] || 0;
    }
    /**
     * Calcular medalla según puntos acumulados
     */
    static getMedal(totalPuntos) {
        if (totalPuntos >= 50)
            return '🏆 Rider de Hierro';
        if (totalPuntos >= 30)
            return '🥇 Oro';
        if (totalPuntos >= 15)
            return '🥈 Plata';
        if (totalPuntos >= 5)
            return '🥉 Bronce';
        return '—';
    }
    /**
     * Obtener color de medalla para UI
     */
    static getMedalColor(totalPuntos) {
        if (totalPuntos >= 50)
            return '#FFD700'; // Dorado especial
        if (totalPuntos >= 30)
            return '#FFD700'; // Oro
        if (totalPuntos >= 15)
            return '#C0C0C0'; // Plata
        if (totalPuntos >= 5)
            return '#CD7F32'; // Bronce
        return '#6B7280'; // Gris
    }
}
exports.EventPointsRules = EventPointsRules;
EventPointsRules.POINTS_MAP = {
    [event_entity_1.EventType.RODADA]: 1,
    [event_entity_1.EventType.ANIVERSARIO]: 1,
    [event_entity_1.EventType.EVENTO_SOCIAL]: 2,
    [event_entity_1.EventType.RALLY_REGIONAL]: 3,
    [event_entity_1.EventType.RALLY_NACIONAL]: 5,
    [event_entity_1.EventType.RALLY_SUDAMERICANO]: 10,
    [event_entity_1.EventType.RUTA_ICONICA]: 10,
    [event_entity_1.EventType.RALLY_INTERNACIONAL]: 15,
    [event_entity_1.EventType.LAMA_HIERRO]: 10,
    [event_entity_1.EventType.ASAMBLEA]: 0, // Obligatoria pero no suma puntos deportivos
    [event_entity_1.EventType.OTRO]: 0
};
//# sourceMappingURL=event-points.rules.js.map