"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NewsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const news_entity_1 = require("./news.entity");
const blob_service_1 = require("../../services/blob.service");
/**
 * Servicio de noticias.
 * Gestiona el workflow de publicación: draft, scheduled, published.
 * Incluye paginación, filtrado por categoría/tags, incremento de vistas y estadísticas.
 */
let NewsService = class NewsService {
    constructor(repo, blob) {
        this.repo = repo;
        this.blob = blob;
    }
    /**
     * Listado paginado y filtrado de noticias.
     * Filtros: status, category, authorId, tags, search (title/excerpt).
     */
    async findAll(options) {
        const page = Math.max(options.page || 1, 1);
        const pageSize = Math.min(Math.max(options.pageSize || 10, 1), 100);
        const qb = this.repo.createQueryBuilder('n')
            .leftJoinAndSelect('n.author', 'author')
            .orderBy('n.publishedAt', 'DESC');
        if (options.status)
            qb.andWhere('n.status = :status', { status: options.status });
        if (options.category)
            qb.andWhere('n.category = :category', { category: options.category });
        if (options.authorId)
            qb.andWhere('n.authorId = :authorId', { authorId: options.authorId });
        if (options.tag) {
            qb.andWhere('n.tags @> :tag', { tag: JSON.stringify([options.tag]) });
        }
        if (options.search) {
            qb.andWhere('(n.title ILIKE :s OR n.excerpt ILIKE :s)', { s: `%${options.search}%` });
        }
        qb.skip((page - 1) * pageSize).take(pageSize);
        const [items, total] = await qb.getManyAndCount();
        return { items, total, page, pageSize };
    }
    async findRecent(limit = 10) {
        return this.repo.find({
            where: { status: 'published' },
            relations: ['author'],
            order: { publishedAt: 'DESC' },
            take: limit
        });
    }
    async findOne(id) {
        const news = await this.repo.findOne({ where: { id }, relations: ['author'] });
        if (!news)
            throw new common_1.NotFoundException('Noticia no encontrada');
        return news;
    }
    async create(dto) {
        const news = this.repo.create({
            ...dto,
            viewCount: 0
        });
        return this.repo.save(news);
    }
    async update(id, dto) {
        const news = await this.findOne(id);
        const updated = { ...dto };
        if (dto.publishedAt) {
            updated.publishedAt = new Date(dto.publishedAt);
        }
        await this.repo.update(id, updated);
        return this.findOne(id);
    }
    async delete(id) {
        const news = await this.findOne(id);
        await this.repo.delete(news.id);
        return { ok: true };
    }
    /**
     * Publicar noticia (cambiar status y establecer publishedAt).
     */
    async publish(id) {
        const news = await this.findOne(id);
        if (news.status === 'published') {
            throw new common_1.BadRequestException('Noticia ya publicada');
        }
        await this.repo.update(id, {
            status: 'published',
            publishedAt: new Date()
        });
        return this.findOne(id);
    }
    /**
     * Despublicar noticia (volver a draft).
     */
    async unpublish(id) {
        const news = await this.findOne(id);
        await this.repo.update(id, { status: 'draft' });
        return this.findOne(id);
    }
    /**
     * Incrementar contador de vistas.
     */
    async incrementView(id) {
        const news = await this.findOne(id);
        await this.repo.update(id, { viewCount: news.viewCount + 1 });
        return this.findOne(id);
    }
    /**
     * Subir imagen destacada.
     */
    async uploadFeaturedImage(id, file) {
        const news = await this.findOne(id);
        if (!file)
            throw new common_1.BadRequestException('Archivo no recibido');
        const key = `news/${id}/featured-${Date.now()}-${file.originalname}`;
        const url = await this.blob.uploadFile(key, file.buffer, file.mimetype);
        await this.repo.update(id, { featuredImageUrl: url });
        return this.findOne(id);
    }
    /**
     * Estadísticas de noticias.
     */
    async stats() {
        const total = await this.repo.count();
        const published = await this.repo.count({ where: { status: 'published' } });
        const draft = await this.repo.count({ where: { status: 'draft' } });
        const mostViewed = await this.repo.find({
            where: { status: 'published' },
            order: { viewCount: 'DESC' },
            take: 5
        });
        const recent = await this.repo.find({
            relations: ['author'],
            order: { createdAt: 'DESC' },
            take: 5
        });
        return { total, published, draft, mostViewed, recent };
    }
};
exports.NewsService = NewsService;
exports.NewsService = NewsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(news_entity_1.News)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        blob_service_1.BlobService])
], NewsService);
//# sourceMappingURL=news.service.js.map