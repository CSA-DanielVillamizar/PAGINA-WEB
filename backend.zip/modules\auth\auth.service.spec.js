"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const testing_1 = require("@nestjs/testing");
const auth_service_1 = require("./auth.service");
const config_1 = require("@nestjs/config");
// Mock ConfigService
class ConfigMock {
    constructor() {
        this.values = {
            FRONTEND_URL: 'http://localhost:5173',
            MULTI_TENANT: 'true'
        };
    }
    get(key) {
        return this.values[key];
    }
}
describe('AuthService', () => {
    let service;
    beforeAll(async () => {
        const module = await testing_1.Test.createTestingModule({
            providers: [
                auth_service_1.AuthService,
                { provide: config_1.ConfigService, useClass: ConfigMock }
            ]
        }).compile();
        service = module.get(auth_service_1.AuthService);
    });
    it('validateUserByEmailDomain marca externo si dominio distinto', () => {
        const result1 = service.validateUserByEmailDomain('alguien@fundacionlamamedellin.org');
        expect(result1.allowed).toBe(true);
        expect(result1.external).toBe(false);
        const result2 = service.validateUserByEmailDomain('otro@otrodominio.com');
        expect(result2.allowed).toBe(true);
        expect(result2.external).toBe(true);
    });
    it('decodeJwt lanza error con token mal formado', async () => {
        await expect(service.validateAzureToken('abc.def')).rejects.toThrow();
    });
});
//# sourceMappingURL=auth.service.spec.js.map