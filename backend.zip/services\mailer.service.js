"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var MailerService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailerService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const communication_email_1 = require("@azure/communication-email");
const nodemailer_1 = __importDefault(require("nodemailer"));
/**
 * Servicio de envío de correos electrónicos
 * Soporta dos proveedores:
 * 1) SMTP (Office 365) vía Nodemailer
 * 2) Azure Communication Services Email
 */
let MailerService = MailerService_1 = class MailerService {
    constructor(configService) {
        this.configService = configService;
        this.logger = new common_1.Logger(MailerService_1.name);
        this.emailClient = null;
        this.smtpTransporter = null;
        this.senderAddress = 'noreply@fundacionlama.org';
        this.enabled = false; // Modo degradado si falla inicialización
        const required = this.configService.get('FEATURE_EMAIL_REQUIRED') === 'true';
        // Intentar SMTP primero si hay configuración
        const smtpHost = this.configService.get('SMTP_HOST');
        const smtpPort = Number(this.configService.get('SMTP_PORT') || '587');
        const smtpUser = this.configService.get('SMTP_USER');
        const smtpPass = this.configService.get('SMTP_PASS');
        const smtpSecureEnv = this.configService.get('SMTP_SECURE');
        const smtpSecure = smtpSecureEnv === 'true' || smtpPort === 465; // STARTTLS -> secure:false
        this.senderAddress = this.configService.get('SMTP_FROM')
            || this.configService.get('EMAIL_SENDER_ADDRESS')
            || this.senderAddress;
        if (smtpHost && smtpUser && smtpPass) {
            try {
                this.smtpTransporter = nodemailer_1.default.createTransport({
                    host: smtpHost,
                    port: smtpPort,
                    secure: smtpSecure, // false para 587 STARTTLS
                    auth: { user: smtpUser, pass: smtpPass },
                    requireTLS: !smtpSecure, // fuerza STARTTLS
                    tls: { minVersion: 'TLSv1.2' },
                });
            }
            catch (err) {
                const msg = `MailerService SMTP: error creando transporter -> ${err.message}`;
                if (required)
                    throw new Error(msg);
                this.logger.error(msg);
            }
        }
        if (this.smtpTransporter) {
            this.enabled = true;
            this.logger.log('MailerService inicializado con SMTP (Nodemailer).');
            return;
        }
        // Fallback: Azure Communication Services
        const connectionString = this.configService.get('AZURE_COMMUNICATION_CONNECTION_STRING');
        if (!connectionString) {
            const msg = 'MailerService deshabilitado: falta SMTP o AZURE_COMMUNICATION_CONNECTION_STRING';
            if (required) {
                this.logger.error(msg);
                throw new Error('FEATURE_EMAIL_REQUIRED habilitado y no hay proveedor SMTP ni ACS configurado');
            }
            this.logger.warn(msg);
            return;
        }
        const normalized = connectionString.trim();
        const looksValid = /^endpoint=https:\/\/.*communication\.azure\.com\/?;accesskey=.+$/i.test(normalized);
        if (!looksValid) {
            const msg = 'MailerService: cadena de conexión ACS inválida (endpoint + accesskey).';
            if (required) {
                this.logger.error(msg);
                throw new Error('Cadena de conexión Azure Communication inválida y servicio marcado como requerido.');
            }
            this.logger.error(msg);
            return;
        }
        try {
            this.emailClient = new communication_email_1.EmailClient(normalized);
            this.enabled = true;
            this.logger.log('MailerService inicializado con Azure Communication Email.');
        }
        catch (error) {
            const msg = `MailerService: error inicializando ACS -> ${error.message}`;
            if (required) {
                this.logger.error(msg);
                throw new Error('Error crítico inicializando MailerService requerido');
            }
            this.logger.error(msg);
            this.logger.warn('MailerService operará en modo degradado (sin envío de correos).');
        }
    }
    isEnabled() {
        return this.enabled && (!!this.emailClient || !!this.smtpTransporter);
    }
    async sendMail(options) {
        if (!this.isEnabled()) {
            this.logger.warn(`MailerService deshabilitado: se omite envío (subject="${options.subject}")`);
            return;
        }
        const recipients = Array.isArray(options.to) ? options.to : [options.to];
        // SMTP
        if (this.smtpTransporter) {
            try {
                const attachments = (options.attachments || []).map(a => ({
                    filename: a.name,
                    content: Buffer.from(a.contentBytesBase64, 'base64'),
                    contentType: a.contentType,
                }));
                await this.smtpTransporter.sendMail({
                    from: this.senderAddress,
                    to: recipients.join(', '),
                    subject: options.subject,
                    text: options.text,
                    html: options.html,
                    attachments,
                });
                this.logger.log(`Correo SMTP enviado a: ${recipients.join(', ')}`);
                return;
            }
            catch (error) {
                this.logger.error(`MailerService SMTP: error enviando correo -> ${error.message}`);
                // No devolvemos; intentamos fallback a ACS si existe
            }
        }
        // ACS
        if (this.emailClient) {
            try {
                const message = {
                    senderAddress: this.senderAddress,
                    content: {
                        subject: options.subject,
                        plainText: options.text,
                        html: options.html,
                    },
                    recipients: { to: recipients.map(email => ({ address: email })) },
                    attachments: options.attachments,
                };
                const poller = await this.emailClient.beginSend(message);
                await poller.pollUntilDone();
                this.logger.log(`Correo ACS enviado a: ${recipients.join(', ')}`);
                return;
            }
            catch (error) {
                this.logger.error(`MailerService ACS: error enviando correo -> ${error.message}`);
            }
        }
    }
    async sendWelcomeEmail(email, name) {
        await this.sendMail({
            to: email,
            subject: 'Bienvenido a Fundación LAMA Medellín',
            html: `
        <h1>¡Bienvenido ${name}!</h1>
        <p>Gracias por unirte a nuestra comunidad.</p>
        <p>Estamos emocionados de tenerte con nosotros.</p>
      `,
        });
    }
    async sendFormConfirmation(email, formType) {
        await this.sendMail({
            to: email,
            subject: 'Confirmación de recepción de formulario',
            html: `
        <h1>Formulario Recibido</h1>
        <p>Hemos recibido tu formulario de tipo: <strong>${formType}</strong></p>
        <p>Te contactaremos pronto.</p>
      `,
        });
    }
};
exports.MailerService = MailerService;
exports.MailerService = MailerService = MailerService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], MailerService);
//# sourceMappingURL=mailer.service.js.map