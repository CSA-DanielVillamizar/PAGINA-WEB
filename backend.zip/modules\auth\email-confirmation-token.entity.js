"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailConfirmationToken = void 0;
const typeorm_1 = require("typeorm");
const user_entity_1 = require("../users/user.entity");
/**
 * Entidad EmailConfirmationToken
 * Almacena tokens de confirmación de correo electrónico para nuevos registros.
 * Se guarda el hash del token (no el token plano) para seguridad.
 * El token expira después de cierto tiempo (expiration). Un token usado se marca como used=true.
 */
let EmailConfirmationToken = class EmailConfirmationToken {
};
exports.EmailConfirmationToken = EmailConfirmationToken;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], EmailConfirmationToken.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ length: 128 }),
    (0, typeorm_1.Index)({ unique: true }),
    __metadata("design:type", String)
], EmailConfirmationToken.prototype, "tokenHash", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz' }),
    __metadata("design:type", Date)
], EmailConfirmationToken.prototype, "expiresAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ default: false }),
    __metadata("design:type", Boolean)
], EmailConfirmationToken.prototype, "used", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.User, { onDelete: 'CASCADE' }),
    __metadata("design:type", user_entity_1.User)
], EmailConfirmationToken.prototype, "user", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)(),
    __metadata("design:type", Date)
], EmailConfirmationToken.prototype, "createdAt", void 0);
exports.EmailConfirmationToken = EmailConfirmationToken = __decorate([
    (0, typeorm_1.Entity)('email_confirmation_tokens')
], EmailConfirmationToken);
//# sourceMappingURL=email-confirmation-token.entity.js.map