// Cargar variables de entorno PRIMERO (antes de importar data-source)
try {
    require('dotenv').config();
}
catch { }
require('reflect-metadata');
const { Logger } = require('@nestjs/common');
const { AppDataSource } = require('./data-source');
const logger = new Logger('Migrations');
/**
 * Normaliza el username para PostgreSQL Flexible Server.
 * Flexible Server no requiere formato user@server, solo el nombre del usuario.
 */
function normalizeUsername(raw) {
    if (!raw)
        return raw;
    const atIndex = raw.indexOf('@');
    return atIndex > 0 ? raw.substring(0, atIndex) : raw;
}
async function run() {
    const start = Date.now();
    const rawUser = process.env.DB_USER;
    const normalizedUser = normalizeUsername(rawUser);
    logger.log('[Migration Runner] Iniciando conexión DB para migraciones...');
    logger.log(`[Migration Runner] DB_USER (raw): ${rawUser}`);
    logger.log(`[Migration Runner] DB_USER (normalized): ${normalizedUser}`);
    // Sobrescribir credenciales en el DataSource antes de inicializar
    AppDataSource.options.username = normalizedUser;
    AppDataSource.options.password = process.env.DB_PASS;
    AppDataSource.options.logging = true; // Mostrar queries durante migración
    try {
        await AppDataSource.initialize();
        logger.log('[Migration Runner] Conexión establecida. Ejecutando migraciones pendientes...');
        await AppDataSource.runMigrations({ transaction: 'all' });
        const elapsed = Date.now() - start;
        logger.log(`[Migration Runner] ✓ Migraciones aplicadas correctamente. Tiempo: ${elapsed}ms`);
        await AppDataSource.destroy();
        logger.log('[Migration Runner] Conexión cerrada.');
    }
    catch (err) {
        logger.error('[Migration Runner] ✗ Error al ejecutar migraciones:', err instanceof Error ? err.message : err);
        if (err instanceof Error && err.stack) {
            console.error('Stack trace completo:', err.stack);
        }
        console.error('Error completo:', err);
        process.exit(1);
    }
}
run();
//# sourceMappingURL=migrations-runner.js.map