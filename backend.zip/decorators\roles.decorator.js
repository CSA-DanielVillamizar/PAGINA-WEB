"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Roles = exports.ROLES_KEY = void 0;
const common_1 = require("@nestjs/common");
/**
 * Clave para almacenar los roles requeridos en el metadata de un endpoint.
 */
exports.ROLES_KEY = 'roles';
/**
 * Decorator que especifica qué roles pueden acceder a un endpoint.
 * Debe usarse junto con RolesGuard.
 *
 * @example
 * @Roles('Administrador', 'Presidente')
 * @Get()
 * findAll() { ... }
 */
const Roles = (...roles) => (0, common_1.SetMetadata)(exports.ROLES_KEY, roles);
exports.Roles = Roles;
//# sourceMappingURL=roles.decorator.js.map