"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
// Se elimina TypeOrmModule.forRootAsync para evitar bloqueo en el arranque.
const config_1 = require("@nestjs/config");
const health_module_1 = require("./modules/health/health.module");
const diagnostics_module_1 = require("./modules/diagnostics/diagnostics.module");
const inscriptions_module_1 = require("./modules/inscriptions/inscriptions.module");
const projects_module_1 = require("./modules/projects/projects.module");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({ isGlobal: true }),
            // Configuración de TypeORM con tolerancia a fallos y reintentos.
            // Si se establece DISABLE_DB=1 en las variables de entorno, se omite la conexión
            // para permitir que la aplicación arranque y exponga endpoints básicos.
            // MÓDULOS BÁSICOS: El arranque nunca debe bloquearse por la base de datos.
            // Los módulos que dependen de repositorios se habilitarán cuando se reintroduzca TypeOrmModule.
            health_module_1.HealthModule,
            diagnostics_module_1.DiagnosticsModule,
            inscriptions_module_1.InscriptionsModule,
            projects_module_1.ProjectsModule, // CRUD proyectos destacados (solo junta)
        ],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map