"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runMigrations = runMigrations;
async function runMigrations(dataSource) {
    if (!dataSource.isInitialized) {
        throw new Error('DataSource no inicializado');
    }
    // El proyecto ya cuenta con `migrations-runner.ts`; aquí podrías reutilizar lógica
    // o directamente invocar dataSource.runMigrations().
    await dataSource.runMigrations({ transaction: 'all' });
}
//# sourceMappingURL=migrations-runner-wrapper.js.map