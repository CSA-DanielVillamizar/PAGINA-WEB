"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VehiclesService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const vehicle_entity_1 = require("./vehicle.entity");
const blob_service_1 = require("../../services/blob.service");
/**
 * Servicio de vehículos.
 * Responsable de aplicar reglas de negocio: paginación, filtrado, transferencia de propietario,
 * mantenimiento del historial y carga de imágenes mediante Blob Storage.
 */
let VehiclesService = class VehiclesService {
    constructor(repo, blob) {
        this.repo = repo;
        this.blob = blob;
    }
    /**
     * Consulta paginada y filtrada de vehículos.
     * Filtros soportados: status, brand, model, year (exacto), search (placa / vin / modelo).
     */
    async findAll(options) {
        const page = Math.max(options.page || 1, 1);
        const pageSize = Math.min(Math.max(options.pageSize || 10, 1), 100);
        const qb = this.repo.createQueryBuilder('v').orderBy('v.createdAt', 'DESC');
        if (options.status)
            qb.andWhere('v.status = :status', { status: options.status });
        if (options.brand)
            qb.andWhere('v.brand ILIKE :brand', { brand: `%${options.brand}%` });
        if (options.model)
            qb.andWhere('v.model ILIKE :model', { model: `%${options.model}%` });
        if (options.year)
            qb.andWhere('v.year = :year', { year: options.year });
        if (options.search) {
            qb.andWhere('(v.licensePlate ILIKE :s OR v.vin ILIKE :s OR v.model ILIKE :s OR v.brand ILIKE :s)', { s: `%${options.search}%` });
        }
        qb.skip((page - 1) * pageSize).take(pageSize);
        const [items, total] = await qb.getManyAndCount();
        return { items, total, page, pageSize };
    }
    async findByUser(userId) {
        return this.repo.find({ where: { ownerUserId: userId } });
    }
    async findOne(id) {
        const vehicle = await this.repo.findOne({ where: { id } });
        if (!vehicle)
            throw new common_1.NotFoundException('Vehículo no encontrado');
        return vehicle;
    }
    async create(dto) {
        const existing = await this.repo.findOne({ where: { licensePlate: dto.licensePlate } });
        if (existing)
            throw new common_1.BadRequestException('La placa ya está registrada');
        const vehicle = this.repo.create({
            ...dto,
            ownershipHistory: [
                { date: new Date().toISOString(), action: 'CREATED', userId: dto.ownerUserId }
            ]
        });
        return this.repo.save(vehicle);
    }
    async update(id, dto) {
        const vehicle = await this.findOne(id);
        let history = vehicle.ownershipHistory || [];
        if (dto.ownerUserId && dto.ownerUserId !== vehicle.ownerUserId) {
            history = [
                ...history,
                { date: new Date().toISOString(), action: 'TRANSFER', userId: dto.ownerUserId }
            ];
        }
        await this.repo.update(id, { ...dto, ownershipHistory: history });
        return this.findOne(id);
    }
    async delete(id) {
        const vehicle = await this.findOne(id);
        await this.repo.delete(vehicle.id);
        return { ok: true };
    }
    async transferOwner(vehicleId, newUserId) {
        const vehicle = await this.findOne(vehicleId);
        const history = vehicle.ownershipHistory || [];
        history.push({ date: new Date().toISOString(), action: 'TRANSFER', userId: newUserId });
        await this.repo.update(vehicleId, { ownerUserId: newUserId, ownershipHistory: history });
        return this.findOne(vehicleId);
    }
    async addImages(vehicleId, files) {
        const vehicle = await this.findOne(vehicleId);
        if (!files || files.length === 0) {
            throw new common_1.BadRequestException('No se recibieron archivos');
        }
        const stored = [];
        for (const file of files) {
            const key = `vehicles/${vehicleId}/${Date.now()}-${file.originalname}`;
            const url = await this.blob.uploadFile(key, file.buffer, file.mimetype);
            stored.push(url);
        }
        const images = (vehicle.images || []).concat(stored);
        await this.repo.update(vehicleId, { images });
        return this.findOne(vehicleId);
    }
    async stats() {
        const total = await this.repo.count();
        const active = await this.repo.count({ where: { status: 'active' } });
        const inactive = await this.repo.count({ where: { status: 'inactive' } });
        const recent = await this.repo.find({ order: { createdAt: 'DESC' }, take: 5 });
        return { total, active, inactive, recent };
    }
};
exports.VehiclesService = VehiclesService;
exports.VehiclesService = VehiclesService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(vehicle_entity_1.Vehicle)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        blob_service_1.BlobService])
], VehiclesService);
//# sourceMappingURL=vehicles.service.js.map