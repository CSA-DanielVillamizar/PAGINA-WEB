"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiagnosticsController = void 0;
const common_1 = require("@nestjs/common");
const blob_service_1 = require("../../services/blob.service");
const mailer_service_1 = require("../../services/mailer.service");
/**
 * Controlador de diagnóstico para verificar servicios externos (Blob Storage y Email).
 * Endpoints seguros para pruebas internas y monitoreo inicial.
 * Rutas: /api/diagnostics/blob y /api/diagnostics/email
 */
let DiagnosticsController = class DiagnosticsController {
    constructor(blob, mailer) {
        this.blob = blob;
        this.mailer = mailer;
    }
    /**
     * Verifica estado del BlobService. Opcionalmente hace una carga de prueba si testUpload=true.
     */
    async checkBlob(testUpload) {
        const enabled = this.blob.isEnabled?.() || false;
        const result = { enabled };
        if (!enabled)
            return result;
        if (testUpload === 'true') {
            const fileName = `diagnostic-${Date.now()}.txt`;
            const buffer = Buffer.from('diagnóstico blob ok');
            try {
                const url = await this.blob.uploadFile(fileName, buffer, 'text/plain');
                result.testUploadUrl = url;
            }
            catch (err) {
                result.testUploadError = err.message;
            }
        }
        return result;
    }
    /**
     * Verifica estado del MailerService. Si se pasa ?to=correo envía correo de prueba.
     */
    async checkEmail(to) {
        const enabled = this.mailer.isEnabled?.() || false;
        const result = { enabled };
        if (!enabled)
            return result;
        if (to) {
            try {
                await this.mailer.sendMail({
                    to,
                    subject: 'Prueba Diagnóstico Email',
                    html: '<h3>Correo de prueba enviado correctamente.</h3>'
                });
                result.sentTo = to;
            }
            catch (err) {
                result.sendError = err.message;
            }
        }
        return result;
    }
};
exports.DiagnosticsController = DiagnosticsController;
__decorate([
    (0, common_1.Get)('blob'),
    __param(0, (0, common_1.Query)('testUpload')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], DiagnosticsController.prototype, "checkBlob", null);
__decorate([
    (0, common_1.Get)('email'),
    __param(0, (0, common_1.Query)('to')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], DiagnosticsController.prototype, "checkEmail", null);
exports.DiagnosticsController = DiagnosticsController = __decorate([
    (0, common_1.Controller)('diagnostics'),
    __metadata("design:paramtypes", [blob_service_1.BlobService, mailer_service_1.MailerService])
], DiagnosticsController);
//# sourceMappingURL=diagnostics.controller.js.map