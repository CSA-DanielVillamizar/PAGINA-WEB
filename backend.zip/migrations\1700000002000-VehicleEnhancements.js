"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VehicleEnhancements1700000002000 = void 0;
const typeorm_1 = require("typeorm");
/**
 * Migración: VehicleEnhancements
 * Agrega campos para soporte de propiedad, historial y galería de imágenes en vehículos.
 * Nuevos campos:
 * - ownerUserId: UUID opcional del miembro propietario actual.
 * - ownershipHistory: JSONB para rastrear eventos de transferencia.
 * - images: JSONB array de URLs de imágenes adicionales.
 */
class VehicleEnhancements1700000002000 {
    async up(queryRunner) {
        // Agregar columna ownerUserId
        await queryRunner.addColumn('vehicles', new typeorm_1.TableColumn({
            name: 'ownerUserId',
            type: 'uuid',
            isNullable: true,
        }));
        // Agregar columna ownershipHistory (JSONB)
        await queryRunner.addColumn('vehicles', new typeorm_1.TableColumn({
            name: 'ownershipHistory',
            type: 'jsonb',
            isNullable: true,
        }));
        // Agregar columna images (JSONB array)
        await queryRunner.addColumn('vehicles', new typeorm_1.TableColumn({
            name: 'images',
            type: 'jsonb',
            isNullable: true,
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('vehicles', 'images');
        await queryRunner.dropColumn('vehicles', 'ownershipHistory');
        await queryRunner.dropColumn('vehicles', 'ownerUserId');
    }
}
exports.VehicleEnhancements1700000002000 = VehicleEnhancements1700000002000;
//# sourceMappingURL=1700000002000-VehicleEnhancements.js.map