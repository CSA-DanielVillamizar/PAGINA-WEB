"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppDataSource = void 0;
require("reflect-metadata");
const typeorm_1 = require("typeorm");
const user_entity_1 = require("./modules/users/user.entity");
const role_entity_1 = require("./modules/roles/role.entity");
const member_profile_entity_1 = require("./modules/members/member-profile.entity");
const event_entity_1 = require("./modules/events/event.entity");
const donation_entity_1 = require("./modules/donations/donation.entity");
const news_entity_1 = require("./modules/news/news.entity");
const souvenir_entity_1 = require("./modules/souvenirs/souvenir.entity");
const subscription_entity_1 = require("./modules/subscriptions/subscription.entity");
const vehicle_entity_1 = require("./modules/vehicles/vehicle.entity");
const application_form_entity_1 = require("./modules/forms/application-form.entity");
const gallery_entity_1 = require("./modules/gallery/gallery.entity");
const email_confirmation_token_entity_1 = require("./modules/auth/email-confirmation-token.entity");
const password_reset_token_entity_1 = require("./modules/auth/password-reset-token.entity");
const refresh_token_entity_1 = require("./modules/auth/refresh-token.entity");
const featured_project_entity_1 = require("./modules/projects/entities/featured-project.entity");
// Importar todas las migraciones
const _1700000000000_InitialSchema_1 = require("./migrations/1700000000000-InitialSchema");
const _1700000001000_AuthTokens_1 = require("./migrations/1700000001000-AuthTokens");
const _1700000002000_VehicleEnhancements_1 = require("./migrations/1700000002000-VehicleEnhancements");
const _1700000003000_EventEnhancements_1 = require("./migrations/1700000003000-EventEnhancements");
const _1700000004000_DonationEnhancements_1 = require("./migrations/1700000004000-DonationEnhancements");
const _1700000005000_GalleryEnhancements_1 = require("./migrations/1700000005000-GalleryEnhancements");
const _1700000006000_NewsEnhancements_1 = require("./migrations/1700000006000-NewsEnhancements");
const _1700000007000_SubscriptionEnhancements_1 = require("./migrations/1700000007000-SubscriptionEnhancements");
const _1700000008000_SouvenirEnhancements_1 = require("./migrations/1700000008000-SouvenirEnhancements");
const _1700000010000_FeaturedProjects_1 = require("./migrations/1700000010000-FeaturedProjects");
/**
 * Normaliza el usuario de conexión eliminando el sufijo '@servidor' si existe.
 * Si no se provee usuario usa 'pgadmin' como valor por defecto.
 * @param u Usuario crudo desde variable de entorno.
 * @returns Usuario normalizado.
 */
function normalizeUser(u) {
    if (!u)
        return 'pgadmin';
    return u.includes('@') ? u.split('@')[0] : u;
}
/**
 * DataSource principal de la aplicación.
 * Soporta password tanto en `DB_PASS` como en `DB_PASSWORD` para tolerar
 * diferencias de nomenclatura en despliegues previos.
 */
const AppDataSource = new typeorm_1.DataSource({
    type: 'postgres',
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT || '5432'),
    username: normalizeUser(process.env.DB_USER),
    password: process.env.DB_PASS || process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    ssl: (process.env.NODE_ENV === 'production' || process.env.DB_SSL === '1')
        ? { rejectUnauthorized: false }
        : false,
    connectTimeoutMS: 15000,
    extra: {
        connectionTimeoutMillis: 15000,
        query_timeout: 30000,
        statement_timeout: 30000,
    },
    entities: [
        user_entity_1.User,
        role_entity_1.Role,
        member_profile_entity_1.MemberProfile,
        event_entity_1.Event,
        donation_entity_1.Donation,
        news_entity_1.News,
        souvenir_entity_1.Souvenir,
        subscription_entity_1.Subscription,
        vehicle_entity_1.Vehicle,
        application_form_entity_1.ApplicationForm,
        gallery_entity_1.GalleryAlbum,
        email_confirmation_token_entity_1.EmailConfirmationToken,
        password_reset_token_entity_1.PasswordResetToken,
        refresh_token_entity_1.RefreshToken,
        featured_project_entity_1.FeaturedProject
    ],
    migrations: [
        _1700000000000_InitialSchema_1.InitialSchema1700000000000,
        _1700000001000_AuthTokens_1.AuthTokens1700000001000,
        _1700000002000_VehicleEnhancements_1.VehicleEnhancements1700000002000,
        _1700000003000_EventEnhancements_1.EventEnhancements1700000003000,
        _1700000004000_DonationEnhancements_1.DonationEnhancements1700000004000,
        _1700000005000_GalleryEnhancements_1.GalleryEnhancements1700000005000,
        _1700000006000_NewsEnhancements_1.NewsEnhancements1700000006000,
        _1700000007000_SubscriptionEnhancements_1.SubscriptionEnhancements1700000007000,
        _1700000008000_SouvenirEnhancements_1.SouvenirEnhancements1700000008000,
        _1700000010000_FeaturedProjects_1.FeaturedProjects1700000010000
    ],
    synchronize: false,
    logging: false,
});
exports.AppDataSource = AppDataSource;
exports.default = AppDataSource;
//# sourceMappingURL=data-source.js.map