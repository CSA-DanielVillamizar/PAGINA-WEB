"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MembersService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const member_profile_entity_1 = require("./member-profile.entity");
const blob_service_1 = require("../../services/blob.service");
/**
 * Servicio de miembros
 * Lógica de negocio para gestión de perfiles de miembros con soporte de filtro, paginación y estadísticas.
 */
let MembersService = class MembersService {
    constructor(repo, blob) {
        this.repo = repo;
        this.blob = blob;
    }
    /**
     * Listado paginado y filtrado de perfiles de miembros.
     * Permite filtrar por status, chapter y buscar por membershipNumber o correo.
     */
    async findAll(options) {
        const { page = 1, pageSize = 20, status, chapter, search } = options;
        const qb = this.repo.createQueryBuilder('m').leftJoinAndSelect('m.user', 'user');
        if (status)
            qb.andWhere('m.status = :status', { status });
        if (chapter)
            qb.andWhere('m.chapter = :chapter', { chapter });
        if (search)
            qb.andWhere('(m.membershipNumber ILIKE :s OR user.correo ILIKE :s)', { s: `%${search}%` });
        qb.orderBy('m.createdAt', 'DESC').skip((page - 1) * pageSize).take(pageSize);
        const [items, total] = await qb.getManyAndCount();
        return { items, total, page, pageSize };
    }
    async findOne(userId) {
        const profile = await this.repo.findOne({ where: { userId }, relations: ['user'] });
        if (!profile)
            throw new common_1.NotFoundException('Perfil no encontrado');
        return profile;
    }
    async create(dto) {
        const profile = this.repo.create({
            ...dto,
            memberSince: dto.memberSince ? new Date(dto.memberSince) : undefined,
            renewalDate: dto.renewalDate ? new Date(dto.renewalDate) : undefined
        });
        return this.repo.save(profile);
    }
    async update(userId, dto) {
        const existing = await this.findOne(userId);
        Object.assign(existing, {
            ...dto,
            memberSince: dto.memberSince ? new Date(dto.memberSince) : existing.memberSince,
            renewalDate: dto.renewalDate ? new Date(dto.renewalDate) : existing.renewalDate
        });
        return this.repo.save(existing);
    }
    async delete(userId) {
        await this.repo.delete({ userId });
        return { ok: true };
    }
    /**
     * Sube imagen de perfil a Blob Storage y actualiza el perfil.
     */
    async uploadProfileImage(userId, file) {
        const profile = await this.findOne(userId);
        const extension = file.originalname.split('.').pop() || 'jpg';
        const blobName = `members/${userId}-${Date.now()}.${extension}`;
        const url = await this.blob.uploadFile(blobName, file.buffer, file.mimetype);
        profile.profileImageUrl = url;
        await this.repo.save(profile);
        return { profileImageUrl: url };
    }
    /**
     * Estadísticas básicas de membresía.
     */
    async stats() {
        const total = await this.repo.count();
        const active = await this.repo.count({ where: { status: 'active' } });
        const inactive = await this.repo.count({ where: { status: 'inactive' } });
        const recent = await this.repo.createQueryBuilder('m')
            .orderBy('m.createdAt', 'DESC')
            .limit(5)
            .getMany();
        return { total, active, inactive, recent };
    }
};
exports.MembersService = MembersService;
exports.MembersService = MembersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(member_profile_entity_1.MemberProfile)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        blob_service_1.BlobService])
], MembersService);
//# sourceMappingURL=members.service.js.map