"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventEnhancements1700000003000 = void 0;
const typeorm_1 = require("typeorm");
/**
 * Migración: EventEnhancements
 * Agrega campos para gestión avanzada de eventos.
 * Nuevos campos:
 * - coverImageUrl: Imagen de portada principal del evento.
 * - registrations: JSONB array con inscripciones de usuarios.
 * - reminders: JSONB array para registro de recordatorios enviados.
 */
class EventEnhancements1700000003000 {
    async up(queryRunner) {
        // Agregar columna coverImageUrl
        await queryRunner.addColumn('events', new typeorm_1.TableColumn({
            name: 'coverImageUrl',
            type: 'varchar',
            length: '500',
            isNullable: true,
        }));
        // Agregar columna registrations (JSONB array)
        await queryRunner.addColumn('events', new typeorm_1.TableColumn({
            name: 'registrations',
            type: 'jsonb',
            isNullable: true,
        }));
        // Agregar columna reminders (JSONB array)
        await queryRunner.addColumn('events', new typeorm_1.TableColumn({
            name: 'reminders',
            type: 'jsonb',
            isNullable: true,
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('events', 'reminders');
        await queryRunner.dropColumn('events', 'registrations');
        await queryRunner.dropColumn('events', 'coverImageUrl');
    }
}
exports.EventEnhancements1700000003000 = EventEnhancements1700000003000;
//# sourceMappingURL=1700000003000-EventEnhancements.js.map