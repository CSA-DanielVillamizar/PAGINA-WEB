"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DonationEnhancements1700000004000 = void 0;
const typeorm_1 = require("typeorm");
class DonationEnhancements1700000004000 {
    async up(queryRunner) {
        await queryRunner.addColumn('donations', new typeorm_1.TableColumn({
            name: 'paymentInfo',
            type: 'jsonb',
            isNullable: true,
            comment: 'Información adicional del pago: gateway, fees, reference, metadata'
        }));
        await queryRunner.addColumn('donations', new typeorm_1.TableColumn({
            name: 'receiptUrl',
            type: 'varchar',
            length: '500',
            isNullable: true,
            comment: 'URL del recibo PDF generado en Azure Blob Storage'
        }));
        await queryRunner.addColumn('donations', new typeorm_1.TableColumn({
            name: 'receiptNumber',
            type: 'varchar',
            length: '100',
            isNullable: true,
            isUnique: true,
            comment: 'Número único de recibo formato REC-YYYYMMDD-XXXX'
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('donations', 'receiptNumber');
        await queryRunner.dropColumn('donations', 'receiptUrl');
        await queryRunner.dropColumn('donations', 'paymentInfo');
    }
}
exports.DonationEnhancements1700000004000 = DonationEnhancements1700000004000;
//# sourceMappingURL=1700000004000-DonationEnhancements.js.map