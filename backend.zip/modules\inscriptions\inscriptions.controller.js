"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InscriptionsController = void 0;
const common_1 = require("@nestjs/common");
const send_inscription_dto_1 = require("./dto/send-inscription.dto");
const mailer_service_1 = require("../../services/mailer.service");
const config_1 = require("@nestjs/config");
let InscriptionsController = class InscriptionsController {
    constructor(mailer, config) {
        this.mailer = mailer;
        this.config = config;
    }
    /**
     * Recibe la solicitud de inscripción, compone un correo a gerencia/fundación y opcionalmente adjunta el PDF.
     * Ruta final: POST /api/inscriptions/send-email (prefijo global /api)
     */
    async sendEmail(body) {
        const receiver = this.config.get('INSCRIPTIONS_RECEIVER') || 'gerencia@fundacionlamamedellin.org';
        const subject = `Nueva inscripción: ${body.fullName}`;
        const safe = (v) => (v ?? '').toString();
        // Render mínimo de los datos principales + metadata plana si llega.
        const meta = body.metadata && typeof body.metadata === 'object' ? body.metadata : {};
        const metaRows = Object.entries(meta)
            .map(([k, v]) => `<tr><td style="padding:4px 8px;border:1px solid #333">${k}</td><td style="padding:4px 8px;border:1px solid #333">${String(v)}</td></tr>`)
            .join('');
        const html = `
      <div style="font-family:Segoe UI,Helvetica,Arial,sans-serif;color:#111">
        <h2 style="margin:0 0 8px 0">Solicitud de inscripción</h2>
        <p style="margin:0 0 12px 0">Se ha recibido una nueva solicitud de inscripción desde el sitio web.</p>
        <table style="border-collapse:collapse;border:1px solid #333">
          <tr><td style="padding:4px 8px;border:1px solid #333">Nombre</td><td style="padding:4px 8px;border:1px solid #333">${safe(body.fullName)}</td></tr>
          <tr><td style="padding:4px 8px;border:1px solid #333">Email</td><td style="padding:4px 8px;border:1px solid #333">${safe(body.email)}</td></tr>
          ${metaRows}
        </table>
      </div>
    `;
        await this.mailer.sendMail({
            to: [receiver],
            subject,
            html,
            // Adjunto PDF si viene; MailerService manejará si soporta o ignora adjuntos
            attachments: body.pdfBase64 && body.pdfFileName ? [{
                    name: body.pdfFileName,
                    contentType: 'application/pdf',
                    contentBytesBase64: body.pdfBase64
                }] : undefined
        });
        return { ok: true };
    }
};
exports.InscriptionsController = InscriptionsController;
__decorate([
    (0, common_1.Post)('send-email'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [send_inscription_dto_1.SendInscriptionDto]),
    __metadata("design:returntype", Promise)
], InscriptionsController.prototype, "sendEmail", null);
exports.InscriptionsController = InscriptionsController = __decorate([
    (0, common_1.Controller)('inscriptions'),
    __metadata("design:paramtypes", [mailer_service_1.MailerService, config_1.ConfigService])
], InscriptionsController);
//# sourceMappingURL=inscriptions.controller.js.map