"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const testing_1 = require("@nestjs/testing");
const roles_service_1 = require("./roles.service");
const typeorm_1 = require("@nestjs/typeorm");
const role_entity_1 = require("./role.entity");
describe('RolesService', () => {
    let service;
    const rolesStore = [];
    const repoMock = {
        find: jest.fn(async () => rolesStore),
        findOne: jest.fn(async ({ where: { name } }) => rolesStore.find(r => r.name === name) || null),
        create: jest.fn((data) => ({ id: data.name + '-id', ...data })),
        save: jest.fn(async (r) => { rolesStore.push(r); return r; })
    };
    beforeAll(async () => {
        const module = await testing_1.Test.createTestingModule({
            providers: [roles_service_1.RolesService, { provide: (0, typeorm_1.getRepositoryToken)(role_entity_1.Role), useValue: repoMock }]
        }).compile();
        service = module.get(roles_service_1.RolesService);
    });
    it('seed debe crear los 10 roles si no existen', async () => {
        await service.seed();
        expect(rolesStore.length).toBe(10);
        expect(rolesStore.some(r => r.name === 'Administrador')).toBe(true);
    });
    it('findByName debe retornar rol existente', async () => {
        const rol = await service.findByName('Administrador');
        expect(rol).toBeDefined();
        expect(rol.name).toBe('Administrador');
    });
});
//# sourceMappingURL=roles.service.spec.js.map