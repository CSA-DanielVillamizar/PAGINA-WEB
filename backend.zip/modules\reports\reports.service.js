"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const sync_1 = require("csv-stringify/sync");
const pdfkit_1 = __importDefault(require("pdfkit"));
const user_entity_1 = require("../users/user.entity");
const member_profile_entity_1 = require("../members/member-profile.entity");
const event_entity_1 = require("../events/event.entity");
const donation_entity_1 = require("../donations/donation.entity");
const souvenir_entity_1 = require("../souvenirs/souvenir.entity");
const subscription_entity_1 = require("../subscriptions/subscription.entity");
/**
 * Servicio para generar reportes en formatos CSV y PDF.
 * Permite exportar datos de diferentes entidades del sistema.
 */
let ReportsService = class ReportsService {
    constructor(usersRepository, membersRepository, eventsRepository, donationsRepository, souvenirsRepository, subscriptionsRepository) {
        this.usersRepository = usersRepository;
        this.membersRepository = membersRepository;
        this.eventsRepository = eventsRepository;
        this.donationsRepository = donationsRepository;
        this.souvenirsRepository = souvenirsRepository;
        this.subscriptionsRepository = subscriptionsRepository;
    }
    /**
     * Genera un reporte de usuarios en formato CSV
     */
    async generateUsersCSV() {
        const users = await this.usersRepository.find({ relations: ['roles'] });
        const data = users.map(user => ({
            ID: user.id,
            'Nombre Completo': user.nombreCompleto,
            Correo: user.correo,
            Usuario: user.usuario || 'N/A',
            Teléfono: user.telefono || 'N/A',
            Género: user.genero || 'N/A',
            Capítulo: user.capitulo || 'N/A',
            Estado: user.estado,
            Roles: user.roles?.map(r => r.name).join(', ') || 'Sin roles',
            'Fecha Registro': user.fechaRegistro?.toISOString().split('T')[0] || 'N/A',
        }));
        const csv = (0, sync_1.stringify)(data, { header: true });
        return Buffer.from(csv);
    }
    /**
     * Genera un reporte de miembros en formato CSV
     */
    async generateMembersCSV() {
        const members = await this.membersRepository.find({ relations: ['user'] });
        const data = members.map(member => ({
            ID: member.userId,
            Nombre: member.user?.nombreCompleto || 'N/A',
            'Número Membresía': member.membershipNumber || 'N/A',
            'Tipo Miembro': member.membershipType || 'N/A',
            Capítulo: member.chapter || 'N/A',
            Estado: member.status || 'N/A',
            'Fecha Ingreso': member.memberSince?.toISOString().split('T')[0] || 'N/A',
        }));
        const csv = (0, sync_1.stringify)(data, { header: true });
        return Buffer.from(csv);
    }
    /**
     * Genera un reporte de eventos en formato CSV
     */
    async generateEventsCSV() {
        const events = await this.eventsRepository.find();
        const data = events.map(event => ({
            ID: event.id,
            Título: event.title,
            Descripción: event.description || 'N/A',
            Fecha: event.eventDate?.toISOString().split('T')[0] || 'N/A',
            Ubicación: event.location || 'N/A',
            Estado: event.status,
            Capacidad: event.capacity,
            Registrados: event.registeredCount,
        }));
        const csv = (0, sync_1.stringify)(data, { header: true });
        return Buffer.from(csv);
    }
    /**
     * Genera un reporte de donaciones en formato CSV
     */
    async generateDonationsCSV() {
        const donations = await this.donationsRepository.find();
        const data = donations.map(donation => ({
            ID: donation.id,
            Usuario: donation.userId || 'Anónimo',
            Monto: `$${donation.amount.toFixed(2)}`,
            Moneda: donation.currency,
            Fecha: donation.createdAt?.toISOString().split('T')[0] || 'N/A',
            'Método Pago': donation.paymentMethod || 'N/A',
            Estado: donation.status,
        }));
        const csv = (0, sync_1.stringify)(data, { header: true });
        return Buffer.from(csv);
    }
    /**
     * Genera un reporte de inventario de souvenirs en formato CSV
     */
    async generateSouvenirsCSV() {
        const souvenirs = await this.souvenirsRepository.find();
        const data = souvenirs.map(item => ({
            ID: item.id,
            Nombre: item.name,
            Descripción: item.description || 'N/A',
            Precio: `$${item.price.toFixed(2)}`,
            Inventario: item.stock,
            Categoría: item.category || 'N/A',
            Estado: item.status,
        }));
        const csv = (0, sync_1.stringify)(data, { header: true });
        return Buffer.from(csv);
    }
    /**
     * Genera un reporte de suscriptores en formato CSV
     */
    async generateSubscriptionsCSV() {
        const subscriptions = await this.subscriptionsRepository.find();
        const data = subscriptions.map(sub => ({
            ID: sub.id,
            Correo: sub.email,
            Nombre: sub.name || 'N/A',
            Tipo: sub.type,
            Fecha: sub.createdAt?.toISOString().split('T')[0] || 'N/A',
            Estado: sub.status,
        }));
        const csv = (0, sync_1.stringify)(data, { header: true });
        return Buffer.from(csv);
    }
    /**
     * Genera un reporte en formato PDF
     * @param title - Título del reporte
     * @param data - Datos a incluir en el PDF
     */
    async generatePDF(title, data) {
        return new Promise((resolve, reject) => {
            const doc = new pdfkit_1.default({ margin: 50 });
            const chunks = [];
            doc.on('data', (chunk) => chunks.push(chunk));
            doc.on('end', () => resolve(Buffer.concat(chunks)));
            doc.on('error', reject);
            // Encabezado
            doc.fontSize(20).text(title, { align: 'center' });
            doc.moveDown();
            doc.fontSize(10).text(`Generado: ${new Date().toLocaleDateString('es-CO')}`, { align: 'center' });
            doc.moveDown(2);
            // Tabla de datos
            doc.fontSize(12);
            data.forEach((item, index) => {
                if (index > 0 && index % 20 === 0) {
                    doc.addPage();
                }
                doc.fontSize(10);
                Object.entries(item).forEach(([key, value]) => {
                    doc.text(`${key}: ${value}`, { continued: false });
                });
                doc.moveDown(0.5);
            });
            doc.end();
        });
    }
    /**
     * Genera un reporte de usuarios en formato PDF
     */
    async generateUsersPDF() {
        const users = await this.usersRepository.find({ relations: ['roles'] });
        const data = users.map(user => ({
            Nombre: user.nombreCompleto,
            Correo: user.correo,
            Capítulo: user.capitulo || 'N/A',
            Roles: user.roles?.map(r => r.name).join(', ') || 'Sin roles',
        }));
        return this.generatePDF('Reporte de Usuarios', data);
    }
    /**
     * Genera un reporte de donaciones en formato PDF
     */
    async generateDonationsPDF() {
        const donations = await this.donationsRepository.find();
        const data = donations.map(donation => ({
            Usuario: donation.userId || 'Anónimo',
            Monto: `$${donation.amount.toFixed(2)}`,
            Fecha: donation.createdAt?.toISOString().split('T')[0] || 'N/A',
            Método: donation.paymentMethod || 'N/A',
        }));
        return this.generatePDF('Reporte de Donaciones', data);
    }
};
exports.ReportsService = ReportsService;
exports.ReportsService = ReportsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __param(1, (0, typeorm_1.InjectRepository)(member_profile_entity_1.MemberProfile)),
    __param(2, (0, typeorm_1.InjectRepository)(event_entity_1.Event)),
    __param(3, (0, typeorm_1.InjectRepository)(donation_entity_1.Donation)),
    __param(4, (0, typeorm_1.InjectRepository)(souvenir_entity_1.Souvenir)),
    __param(5, (0, typeorm_1.InjectRepository)(subscription_entity_1.Subscription)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], ReportsService);
//# sourceMappingURL=reports.service.js.map