"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var HealthService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthService = void 0;
const common_1 = require("@nestjs/common");
const identity_1 = require("@azure/identity");
const keyvault_secrets_1 = require("@azure/keyvault-secrets");
const database_provider_1 = require("../../database/database.provider");
/**
 * Servicio de verificación de salud y readiness.
 * Encapsula lógica para validar dependencias externas críticas.
 */
let HealthService = HealthService_1 = class HealthService {
    constructor() {
        this.logger = new common_1.Logger(HealthService_1.name);
        // Skip Key Vault initialization if DB is disabled (modo mínimo)
        if (process.env.DISABLE_DB === '1') {
            this.logger.log('DISABLE_DB=1: Skipping Key Vault initialization');
            return;
        }
        const keyVaultName = process.env.KEY_VAULT_NAME;
        if (keyVaultName) {
            try {
                const credential = new identity_1.DefaultAzureCredential();
                this.keyVaultClient = new keyvault_secrets_1.SecretClient(`https://${keyVaultName}.vault.azure.net`, credential);
            }
            catch (err) {
                this.logger.warn('No se pudo inicializar cliente de Key Vault: ' + err.message);
            }
        }
    }
    /**
     * Ejecuta los chequeos de readiness (DB y Key Vault).
     * @returns Resultado agregado y estados individuales.
     */
    async readinessChecks() {
        const dbOk = await this.checkDatabase();
        const kvOk = await this.checkKeyVault();
        return {
            overall: dbOk && kvOk,
            database: { status: dbOk ? 'ok' : 'error' },
            keyVault: { status: kvOk ? 'ok' : 'unavailable' }
        };
    }
    /**
     * Verifica conectividad básica con la base de datos ejecutando un query simple.
     */
    async checkDatabase() {
        if (process.env.DISABLE_DB === '1')
            return true;
        try {
            if (!database_provider_1.AppDataSource.isInitialized) {
                // No forzamos initialize aquí para mantener lazy init.
                return false;
            }
            await database_provider_1.AppDataSource.query('SELECT 1');
            return true;
        }
        catch (err) {
            this.logger.error('Fallo chequeo DB: ' + err.message);
            return false;
        }
    }
    /**
     * Verifica acceso a Key Vault intentando listar un secreto conocido opcional.
     */
    async checkKeyVault() {
        if (!this.keyVaultClient)
            return false;
        try {
            // Intento: leer metadatos de un secreto que debería existir (por ejemplo ENTRA-CLIENT-ID)
            const secretName = process.env.ENTRA_CLIENT_ID ? 'ENTRA-CLIENT-ID' : undefined;
            if (secretName) {
                await this.keyVaultClient.getSecret(secretName);
            }
            else {
                // Si no hay variable indicador, al menos lista una operación trivial (no disponible sin nombre)
            }
            return true;
        }
        catch (err) {
            this.logger.warn('Fallo chequeo Key Vault: ' + err.message);
            return false;
        }
    }
};
exports.HealthService = HealthService;
exports.HealthService = HealthService = HealthService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], HealthService);
//# sourceMappingURL=health.service.js.map