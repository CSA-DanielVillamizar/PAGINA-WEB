"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NewsEnhancements1700000006000 = void 0;
const typeorm_1 = require("typeorm");
class NewsEnhancements1700000006000 {
    async up(queryRunner) {
        await queryRunner.addColumn('news', new typeorm_1.TableColumn({
            name: 'featuredImageUrl',
            type: 'varchar',
            length: '500',
            isNullable: true,
            comment: 'URL de la imagen destacada del artículo'
        }));
        await queryRunner.addColumn('news', new typeorm_1.TableColumn({
            name: 'tags',
            type: 'jsonb',
            isNullable: true,
            default: "'[]'",
            comment: 'Array de etiquetas para categorización y filtrado'
        }));
        await queryRunner.addColumn('news', new typeorm_1.TableColumn({
            name: 'viewCount',
            type: 'int',
            default: 0,
            comment: 'Contador de visualizaciones del artículo'
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('news', 'viewCount');
        await queryRunner.dropColumn('news', 'tags');
        await queryRunner.dropColumn('news', 'featuredImageUrl');
    }
}
exports.NewsEnhancements1700000006000 = NewsEnhancements1700000006000;
//# sourceMappingURL=1700000006000-NewsEnhancements.js.map