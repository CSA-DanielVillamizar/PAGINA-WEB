"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const health_service_1 = require("./health.service");
const database_provider_1 = require("../../database/database.provider");
/**
 * Controlador de salud del servicio.
 * Provee un endpoint simple para verificación de vida (liveness) y readiness básica.
 * Útil para monitoreo, pruebas de despliegue y chequeos de infraestructura.
 */
let HealthController = class HealthController {
    constructor(healthService) {
        this.healthService = healthService;
    }
    /**
     * Endpoint de verificación de estado.
     * Retorna información mínima para confirmar que el proceso está activo.
     * @returns Objeto con estado, nombre del servicio, marca de tiempo y versión.
     */
    getStatus() {
        // Estado resumido de la base de datos sin bloquear el endpoint.
        const dbStatus = (0, database_provider_1.getDatabaseStatus)();
        const dbErr = (0, database_provider_1.getDatabaseError)();
        return {
            status: 'ok',
            service: 'lama-backend',
            timestamp: new Date().toISOString(),
            version: process.env.APP_VERSION || '1.0.0',
            database: dbStatus,
            databaseError: dbStatus === 'error' ? dbErr?.message : undefined
        };
    }
    /**
     * Endpoint de readiness.
     * Verifica componentes críticos: conexión a base de datos y acceso a Key Vault.
     * No expone valores sensibles, sólo estados.
     * @returns Objeto con estado global y detalle de subsistemas.
     */
    async getReadiness() {
        const checks = await this.healthService.readinessChecks();
        return {
            status: checks.overall ? 'ready' : 'degraded',
            timestamp: new Date().toISOString(),
            database: (0, database_provider_1.getDatabaseStatus)(),
            keyVault: checks.keyVault,
            overall: checks.overall
        };
    }
};
exports.HealthController = HealthController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Verificar estado del backend' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], HealthController.prototype, "getStatus", null);
__decorate([
    (0, common_1.Get)('ready'),
    (0, swagger_1.ApiOperation)({ summary: 'Verificar preparación de dependencias (DB, Key Vault)' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], HealthController.prototype, "getReadiness", null);
exports.HealthController = HealthController = __decorate([
    (0, swagger_1.ApiTags)('health'),
    (0, common_1.Controller)('health'),
    __metadata("design:paramtypes", [health_service_1.HealthService])
], HealthController);
//# sourceMappingURL=health.controller.js.map