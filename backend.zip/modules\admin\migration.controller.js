"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MigrationController = void 0;
const common_1 = require("@nestjs/common");
const data_source_1 = require("../../data-source");
/**
 * Controlador temporal para ejecutar migraciones manualmente desde HTTP.
 * SOLO para desarrollo - debe ser protegido o removido en producción.
 */
let MigrationController = class MigrationController {
    async runMigrations() {
        try {
            // Inicializar si no está conectado
            if (!data_source_1.AppDataSource.isInitialized) {
                await data_source_1.AppDataSource.initialize();
            }
            const pendingMigrations = await data_source_1.AppDataSource.showMigrations();
            if (!pendingMigrations) {
                return {
                    success: true,
                    message: 'No pending migrations',
                    executed: [],
                };
            }
            const migrations = await data_source_1.AppDataSource.runMigrations({ transaction: 'all' });
            return {
                success: true,
                message: `Executed ${migrations.length} migration(s)`,
                executed: migrations.map(m => m.name),
            };
        }
        catch (error) {
            return {
                success: false,
                message: error instanceof Error ? error.message : 'Unknown error',
                error: error instanceof Error ? error.stack : undefined,
            };
        }
    }
};
exports.MigrationController = MigrationController;
__decorate([
    (0, common_1.Post)('run-migrations'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], MigrationController.prototype, "runMigrations", null);
exports.MigrationController = MigrationController = __decorate([
    (0, common_1.Controller)('admin')
], MigrationController);
//# sourceMappingURL=migration.controller.js.map