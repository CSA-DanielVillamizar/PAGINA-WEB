"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GalleryEnhancements1700000005000 = void 0;
const typeorm_1 = require("typeorm");
class GalleryEnhancements1700000005000 {
    async up(queryRunner) {
        await queryRunner.addColumn('gallery_albums', new typeorm_1.TableColumn({
            name: 'thumbnailUrl',
            type: 'varchar',
            length: '500',
            isNullable: true,
            comment: 'URL de la imagen de portada del álbum'
        }));
        await queryRunner.addColumn('gallery_albums', new typeorm_1.TableColumn({
            name: 'metadata',
            type: 'jsonb',
            isNullable: true,
            comment: 'Metadatos adicionales: photographer, tags, location'
        }));
        // Agregar timestamps si no existen (createdAt y updatedAt ya podrían estar)
        const table = await queryRunner.getTable('gallery_albums');
        if (table && !table.findColumnByName('createdAt')) {
            await queryRunner.addColumn('gallery_albums', new typeorm_1.TableColumn({
                name: 'createdAt',
                type: 'timestamp',
                default: 'CURRENT_TIMESTAMP'
            }));
        }
        if (table && !table.findColumnByName('updatedAt')) {
            await queryRunner.addColumn('gallery_albums', new typeorm_1.TableColumn({
                name: 'updatedAt',
                type: 'timestamp',
                default: 'CURRENT_TIMESTAMP',
                onUpdate: 'CURRENT_TIMESTAMP'
            }));
        }
    }
    async down(queryRunner) {
        const table = await queryRunner.getTable('gallery_albums');
        if (table && table.findColumnByName('updatedAt')) {
            await queryRunner.dropColumn('gallery_albums', 'updatedAt');
        }
        if (table && table.findColumnByName('createdAt')) {
            await queryRunner.dropColumn('gallery_albums', 'createdAt');
        }
        await queryRunner.dropColumn('gallery_albums', 'metadata');
        await queryRunner.dropColumn('gallery_albums', 'thumbnailUrl');
    }
}
exports.GalleryEnhancements1700000005000 = GalleryEnhancements1700000005000;
//# sourceMappingURL=1700000005000-GalleryEnhancements.js.map