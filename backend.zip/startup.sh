#!/bin/sh
cd /home/site/wwwroot
npm install --only=production
node main.js
