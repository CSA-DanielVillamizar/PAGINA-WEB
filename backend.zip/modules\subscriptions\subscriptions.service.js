"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const subscription_entity_1 = require("./subscription.entity");
const crypto_1 = require("crypto");
let SubscriptionsService = class SubscriptionsService {
    constructor(repo) {
        this.repo = repo;
    }
    /**
     * Obtener todas las suscripciones con paginación y filtros.
     */
    async findAll(options) {
        const page = options?.page || 1;
        const limit = options?.limit || 10;
        const skip = (page - 1) * limit;
        const query = this.repo
            .createQueryBuilder('s')
            .leftJoinAndSelect('s.user', 'user');
        if (options?.status) {
            query.andWhere('s.status = :status', { status: options.status });
        }
        if (options?.type) {
            query.andWhere('s.type = :type', { type: options.type });
        }
        if (options?.search) {
            query.andWhere('(s.email ILIKE :search OR s.name ILIKE :search)', {
                search: `%${options.search}%`
            });
        }
        query.skip(skip).take(limit).orderBy('s.createdAt', 'DESC');
        const [data, total] = await query.getManyAndCount();
        return {
            data,
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit)
        };
    }
    /**
     * Buscar suscripción por email.
     */
    async findByEmail(correo) {
        return this.repo.findOne({ where: { email: correo } });
    }
    /**
     * Buscar suscripción por ID.
     */
    async findOne(id) {
        return this.repo.findOne({ where: { id }, relations: ['user'] });
    }
    /**
     * Crear nueva suscripción con token de confirmación.
     */
    async subscribe(dto) {
        const existing = await this.findByEmail(dto.email);
        if (existing && existing.status === 'active') {
            return { ok: false, message: 'El email ya está suscrito' };
        }
        const confirmToken = (0, crypto_1.randomUUID)();
        const unsubscribeToken = (0, crypto_1.randomUUID)();
        const subscription = this.repo.create({
            ...dto,
            status: 'pending',
            confirmToken,
            unsubscribeToken
        });
        const saved = await this.repo.save(subscription);
        // TODO: Enviar email de confirmación con link: /subscriptions/confirm/${confirmToken}
        // await this.mailerService.sendConfirmationEmail(saved.email, confirmToken)
        return { ok: true, data: saved, confirmToken };
    }
    /**
     * Confirmar suscripción mediante token.
     */
    async confirm(token) {
        const subscription = await this.repo.findOne({ where: { confirmToken: token } });
        if (!subscription) {
            return { ok: false, message: 'Token inválido o expirado' };
        }
        if (subscription.confirmedAt) {
            return { ok: false, message: 'La suscripción ya está confirmada' };
        }
        subscription.confirmedAt = new Date();
        subscription.status = 'active';
        subscription.confirmToken = null; // Invalida el token tras confirmación
        await this.repo.save(subscription);
        return { ok: true, message: 'Suscripción confirmada exitosamente', data: subscription };
    }
    /**
     * Dar de baja suscripción por email (método legacy).
     */
    async unsubscribe(correo) {
        const subscription = await this.findByEmail(correo);
        if (!subscription) {
            return { ok: false, message: 'Email no encontrado' };
        }
        subscription.status = 'inactive';
        subscription.unsubscribedAt = new Date();
        await this.repo.save(subscription);
        return { ok: true, message: 'Suscripción cancelada' };
    }
    /**
     * Dar de baja suscripción mediante token único.
     */
    async unsubscribeByToken(token) {
        const subscription = await this.repo.findOne({ where: { unsubscribeToken: token } });
        if (!subscription) {
            return { ok: false, message: 'Token inválido' };
        }
        if (subscription.status === 'inactive') {
            return { ok: false, message: 'La suscripción ya está cancelada' };
        }
        subscription.status = 'inactive';
        subscription.unsubscribedAt = new Date();
        await this.repo.save(subscription);
        return { ok: true, message: 'Suscripción cancelada exitosamente', data: subscription };
    }
    /**
     * Actualizar suscripción.
     */
    async update(id, dto) {
        const subscription = await this.findOne(id);
        if (!subscription) {
            return { ok: false, message: 'Suscripción no encontrada' };
        }
        Object.assign(subscription, dto);
        const updated = await this.repo.save(subscription);
        return { ok: true, data: updated };
    }
    /**
     * Eliminar suscripción.
     */
    async delete(id) {
        const result = await this.repo.delete(id);
        return { ok: result.affected > 0 };
    }
    /**
     * Reenviar email de confirmación.
     */
    async resendConfirmation(email) {
        const subscription = await this.findByEmail(email);
        if (!subscription) {
            return { ok: false, message: 'Email no encontrado' };
        }
        if (subscription.confirmedAt) {
            return { ok: false, message: 'La suscripción ya está confirmada' };
        }
        // Genera nuevo token si el anterior expiró o se perdió
        if (!subscription.confirmToken) {
            subscription.confirmToken = (0, crypto_1.randomUUID)();
            await this.repo.save(subscription);
        }
        // TODO: Reenviar email de confirmación
        // await this.mailerService.sendConfirmationEmail(subscription.email, subscription.confirmToken)
        return { ok: true, message: 'Email de confirmación reenviado', confirmToken: subscription.confirmToken };
    }
    /**
     * Obtener estadísticas de suscripciones.
     */
    async stats() {
        const [total, active, pending, inactive] = await Promise.all([
            this.repo.count(),
            this.repo.count({ where: { status: 'active' } }),
            this.repo.count({ where: { status: 'pending' } }),
            this.repo.count({ where: { status: 'inactive' } })
        ]);
        const recent = await this.repo.find({
            order: { createdAt: 'DESC' },
            take: 5,
            relations: ['user']
        });
        return {
            total,
            active,
            pending,
            inactive,
            recent
        };
    }
};
exports.SubscriptionsService = SubscriptionsService;
exports.SubscriptionsService = SubscriptionsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(subscription_entity_1.Subscription)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], SubscriptionsService);
//# sourceMappingURL=subscriptions.service.js.map