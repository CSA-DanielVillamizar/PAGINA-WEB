"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AuthService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const msal_node_1 = require("@azure/msal-node");
const bcrypt = __importStar(require("bcrypt"));
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const user_entity_1 = require("../users/user.entity");
const email_confirmation_token_entity_1 = require("./email-confirmation-token.entity");
const password_reset_token_entity_1 = require("./password-reset-token.entity");
const refresh_token_entity_1 = require("./refresh-token.entity");
const jwt_1 = require("@nestjs/jwt");
const crypto = __importStar(require("crypto"));
const mailer_service_1 = require("../../services/mailer.service");
/**
 * Servicio de autenticación con Microsoft Entra ID (Azure AD) y JWT.
 * Ahora soporta modo multi-tenant (common/organizations) y validación flexible de dominio externo.
 * Incluye retry exponencial en adquisición de tokens y parsing robusto de claims.
 */
let AuthService = AuthService_1 = class AuthService {
    constructor(configService, usersRepo, emailTokenRepo, passwordTokenRepo, refreshTokenRepo, jwtService, mailer) {
        this.configService = configService;
        this.usersRepo = usersRepo;
        this.emailTokenRepo = emailTokenRepo;
        this.passwordTokenRepo = passwordTokenRepo;
        this.refreshTokenRepo = refreshTokenRepo;
        this.jwtService = jwtService;
        this.mailer = mailer;
        this.logger = new common_1.Logger(AuthService_1.name);
        this.allowedDomain = this.configService.get('ALLOWED_EMAIL_DOMAIN') || 'fundacionlamamedellin.org';
        // Determinar authority: si MULTI_TENANT=true usar 'common', caso contrario tenant específico.
        const multiTenant = this.configService.get('MULTI_TENANT') === 'true';
        const tenantId = this.configService.get('ENTRA_TENANT_ID');
        const authority = multiTenant
            ? 'https://login.microsoftonline.com/common'
            : `https://login.microsoftonline.com/${tenantId}`;
        // En pruebas unitarias podemos inyectar valores dummy para evitar error de credenciales vacías.
        const clientId = this.configService.get('ENTRA_CLIENT_ID') || 'test-client-id';
        const clientSecret = this.configService.get('ENTRA_CLIENT_SECRET') || 'test-client-secret';
        const msalConfig = {
            auth: {
                clientId,
                authority,
                clientSecret,
            },
            system: {
                loggerOptions: {
                    loggerCallback: (level, message) => {
                        if (level <= 2)
                            this.logger.debug(message);
                    },
                    piiLoggingEnabled: false,
                    logLevel: 2
                }
            }
        };
        this.msalClient = new msal_node_1.ConfidentialClientApplication(msalConfig);
    }
    /**
     * Valida si el correo coincide con el dominio permitido, aunque dicho dominio no esté verificado en el tenant.
     * Si el dominio no coincide, se permite el acceso pero se marca como externo (para futura lógica).
     */
    validateUserByEmailDomain(email) {
        const lower = email.toLowerCase();
        const domainPart = lower.split('@')[1] || '';
        if (domainPart === this.allowedDomain) {
            return { allowed: true, external: false };
        }
        // Permitimos acceso, pero marcamos usuario externo para posible restricción de roles avanzados.
        return { allowed: true, external: true };
    }
    /** Encripta contraseña (uso eventual para cuentas locales complementarias). */
    async hashPassword(password) {
        return bcrypt.hash(password, 10);
    }
    /** Compara hash. */
    async comparePassword(password, hash) {
        return bcrypt.compare(password, hash);
    }
    /** Genera token aleatorio seguro en formato hexadecimal. */
    generateRawToken(bytes = 32) {
        return crypto.randomBytes(bytes).toString('hex');
    }
    /** Hashea token plano con SHA-256. */
    hashToken(raw) {
        return crypto.createHash('sha256').update(raw).digest('hex');
    }
    /** Tiempo actual + minutos. */
    minutesFromNow(minutes) {
        return new Date(Date.now() + minutes * 60000);
    }
    /** Registro de usuario con estado PENDING_CONFIRMATION y envío de email de confirmación. */
    async register(email, password, fullName) {
        const existing = await this.usersRepo.findOne({ where: { correo: email.toLowerCase() } });
        if (existing)
            throw new common_1.BadRequestException('Correo ya registrado');
        const passwordHash = await this.hashPassword(password);
        let user = this.usersRepo.create({
            correo: email.toLowerCase(),
            nombreCompleto: fullName,
            passwordHash,
            estado: 'PENDING_CONFIRMATION'
        });
        user = await this.usersRepo.save(user);
        // Generar token confirmación
        const rawToken = this.generateRawToken(24);
        const tokenHash = this.hashToken(rawToken);
        const emailToken = this.emailTokenRepo.create({
            tokenHash,
            user,
            expiresAt: this.minutesFromNow(60), // 1 hora
        });
        await this.emailTokenRepo.save(emailToken);
        // Enviar email si Mailer habilitado
        const frontendBase = this.configService.get('FRONTEND_URL') || 'https://lama-frontend';
        const confirmUrl = `${frontendBase}/auth/confirmar-email?token=${rawToken}`;
        if (this.mailer.isEnabled()) {
            await this.mailer.sendMail({
                to: user.correo,
                subject: 'Confirmación de correo - Fundación LAMA Medellín',
                html: `<h1>Confirmación de correo</h1><p>Hola ${fullName},</p><p>Por favor confirma tu correo haciendo clic en el siguiente enlace:</p><p><a href="${confirmUrl}">${confirmUrl}</a></p><p>Este enlace expira en 60 minutos.</p>`
            });
        }
        return { id: user.id, correo: user.correo, estado: user.estado };
    }
    /** Confirma email con token plano. */
    async confirmEmail(rawToken) {
        const tokenHash = this.hashToken(rawToken);
        const record = await this.emailTokenRepo.findOne({ where: { tokenHash }, relations: ['user'] });
        if (!record)
            throw new common_1.BadRequestException('Token inválido');
        if (record.used)
            throw new common_1.BadRequestException('Token ya utilizado');
        if (record.expiresAt < new Date())
            throw new common_1.BadRequestException('Token expirado');
        const user = record.user;
        user.estado = 'ACTIVE';
        await this.usersRepo.save(user);
        record.used = true;
        await this.emailTokenRepo.save(record);
        return { confirmado: true, userId: user.id };
    }
    /** Login con email/password (solo usuarios ACTIVE). */
    async loginLocal(email, password) {
        const user = await this.usersRepo.findOne({ where: { correo: email.toLowerCase() }, relations: ['roles'] });
        if (!user)
            throw new common_1.UnauthorizedException('Credenciales inválidas');
        if (user.estado !== 'ACTIVE')
            throw new common_1.UnauthorizedException('Usuario no activo');
        if (!user.passwordHash || !(await this.comparePassword(password, user.passwordHash))) {
            throw new common_1.UnauthorizedException('Credenciales inválidas');
        }
        const accessToken = this.createAccessToken(user);
        const refresh = await this.issueRefreshToken(user);
        return { accessToken, refreshToken: refresh.raw, user: this.publicUser(user) };
    }
    /** Crea JWT de acceso. */
    createAccessToken(user) {
        const payload = {
            sub: user.id,
            email: user.correo,
            roles: user.roles?.map(r => r.name) || [],
            capitulo: user.capitulo || null
        };
        return this.jwtService.sign(payload, { expiresIn: '20m' });
    }
    /** Emite refresh token persistiendo hash. */
    async issueRefreshToken(user) {
        const raw = this.generateRawToken(32);
        const tokenHash = this.hashToken(raw);
        const record = this.refreshTokenRepo.create({
            tokenHash,
            user,
            expiresAt: this.minutesFromNow(60 * 24 * 15) // 15 días
        });
        await this.refreshTokenRepo.save(record);
        return { raw, recordId: record.id };
    }
    /** Endpoint refresh: rota refresh token y devuelve nuevo access+refresh. */
    async refresh(rawRefreshToken) {
        const tokenHash = this.hashToken(rawRefreshToken);
        const record = await this.refreshTokenRepo.findOne({ where: { tokenHash }, relations: ['user'] });
        if (!record || record.revoked)
            throw new common_1.UnauthorizedException('Refresh token inválido');
        if (record.expiresAt < new Date())
            throw new common_1.UnauthorizedException('Refresh token expirado');
        const user = await this.usersRepo.findOne({ where: { id: record.user.id }, relations: ['roles'] });
        if (!user)
            throw new common_1.UnauthorizedException('Usuario no encontrado');
        // Revocar token anterior
        record.revoked = true;
        await this.refreshTokenRepo.save(record);
        const accessToken = this.createAccessToken(user);
        const newRefresh = await this.issueRefreshToken(user);
        return { accessToken, refreshToken: newRefresh.raw };
    }
    /** Solicitud de recuperación de contraseña. */
    async forgotPassword(email) {
        const user = await this.usersRepo.findOne({ where: { correo: email.toLowerCase() } });
        if (!user)
            throw new common_1.NotFoundException('Correo no registrado');
        const rawToken = this.generateRawToken(24);
        const tokenHash = this.hashToken(rawToken);
        const reset = this.passwordTokenRepo.create({
            tokenHash,
            user,
            expiresAt: this.minutesFromNow(30) // 30 minutos
        });
        await this.passwordTokenRepo.save(reset);
        const frontendBase = this.configService.get('FRONTEND_URL') || 'https://lama-frontend';
        const resetUrl = `${frontendBase}/auth/reset-password?token=${rawToken}`;
        if (this.mailer.isEnabled()) {
            await this.mailer.sendMail({
                to: user.correo,
                subject: 'Recuperación de contraseña - Fundación LAMA Medellín',
                html: `<h1>Recuperación de contraseña</h1><p>Solicitaste restablecer tu contraseña.</p><p>Haz clic en: <a href="${resetUrl}">${resetUrl}</a></p><p>Expira en 30 minutos.</p>`
            });
        }
        return { enviado: true };
    }
    /** Reseteo de contraseña con token. */
    async resetPassword(rawToken, newPassword) {
        const tokenHash = this.hashToken(rawToken);
        const record = await this.passwordTokenRepo.findOne({ where: { tokenHash }, relations: ['user'] });
        if (!record)
            throw new common_1.BadRequestException('Token inválido');
        if (record.used)
            throw new common_1.BadRequestException('Token ya utilizado');
        if (record.expiresAt < new Date())
            throw new common_1.BadRequestException('Token expirado');
        const user = record.user;
        user.passwordHash = await this.hashPassword(newPassword);
        await this.usersRepo.save(user);
        record.used = true;
        await this.passwordTokenRepo.save(record);
        return { actualizado: true };
    }
    /** Representación pública del usuario. */
    publicUser(user) {
        return {
            id: user.id,
            nombreCompleto: user.nombreCompleto,
            correo: user.correo,
            roles: user.roles?.map(r => r.name) || [],
            estado: user.estado
        };
    }
    /**
     * Adquiere token usando authorization code con retry exponencial para errores transitorios.
     */
    async acquireTokenByCode(code) {
        const redirectUri = `${this.configService.get('FRONTEND_URL')}/auth/callback`;
        const tokenRequest = {
            code,
            scopes: ['User.Read'],
            redirectUri,
        };
        const maxRetries = 3;
        let attempt = 0;
        while (true) {
            try {
                const response = await this.msalClient.acquireTokenByCode(tokenRequest);
                return response;
            }
            catch (error) {
                const isAuthError = error instanceof msal_node_1.AuthError;
                attempt++;
                if (!isAuthError || attempt >= maxRetries) {
                    this.logger.error(`Error definitivo acquiring token: ${error.message}`);
                    throw new Error('Error al obtener token de Azure AD');
                }
                const delay = 300 * attempt * attempt; // Backoff cuadrático
                this.logger.warn(`Fallo acquiring token (intento ${attempt}) reintentando en ${delay}ms`);
                await new Promise(res => setTimeout(res, delay));
            }
        }
    }
    /**
     * Decodifica el JWT sin validación criptográfica (para entorno dev); en prod usar librerías oficiales o Graph.
     */
    decodeJwt(accessToken) {
        const [headerB64, payloadB64] = accessToken.split('.').slice(0, 2);
        if (!payloadB64)
            throw new Error('JWT mal formado');
        const base64 = payloadB64.replace(/-/g, '+').replace(/_/g, '/');
        const json = Buffer.from(base64, 'base64').toString('utf8');
        return JSON.parse(json);
    }
    /**
     * Valida token de Azure y retorna datos normalizados. Marca usuario como externo si dominio difiere.
     */
    async validateAzureToken(accessToken) {
        try {
            const payload = this.decodeJwt(accessToken);
            // Campos posibles según tipo de cuenta (AAD vs MSA): preferred_username, upn, email
            const email = (payload.preferred_username || payload.upn || payload.email || '').toLowerCase();
            if (!email)
                throw new Error('No se encontró claim de correo en el token');
            const domainInfo = this.validateUserByEmailDomain(email);
            return {
                email,
                name: payload.name || payload.given_name || email.split('@')[0],
                id: payload.oid || payload.sub,
                external: domainInfo.external
            };
        }
        catch (error) {
            this.logger.error('Error validating Azure token', error instanceof Error ? error.stack : String(error));
            throw new Error('Token de Azure AD inválido');
        }
    }
    /** Genera URL de autorización Microsoft (multi-tenant si configurado). */
    async getAuthorizationUrl() {
        const redirectUri = `${this.configService.get('FRONTEND_URL')}/auth/callback`;
        const parameters = {
            scopes: ['User.Read'],
            redirectUri,
        };
        return this.msalClient.getAuthCodeUrl(parameters);
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = AuthService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __param(2, (0, typeorm_1.InjectRepository)(email_confirmation_token_entity_1.EmailConfirmationToken)),
    __param(3, (0, typeorm_1.InjectRepository)(password_reset_token_entity_1.PasswordResetToken)),
    __param(4, (0, typeorm_1.InjectRepository)(refresh_token_entity_1.RefreshToken)),
    __metadata("design:paramtypes", [config_1.ConfigService,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        jwt_1.JwtService,
        mailer_service_1.MailerService])
], AuthService);
//# sourceMappingURL=auth.service.js.map