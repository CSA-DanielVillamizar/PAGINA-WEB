"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const event_entity_1 = require("./entities/event.entity");
const event_participant_entity_1 = require("./entities/event-participant.entity");
const event_points_rules_1 = require("./rules/event-points.rules");
/**
 * Service de eventos y participación
 * Sistema completo L.A.M.A. Medellín: CRUD eventos, inscripciones, ranking, puntos
 */
let EventsService = class EventsService {
    constructor(eventRepository, participantRepository) {
        this.eventRepository = eventRepository;
        this.participantRepository = participantRepository;
    }
    /**
     * Crear nuevo evento (solo admin/junta)
     */
    async create(createEventDto) {
        const existingEvent = await this.eventRepository.findOne({
            where: { slug: createEventDto.slug }
        });
        if (existingEvent) {
            throw new common_1.BadRequestException(`El slug "${createEventDto.slug}" ya está en uso`);
        }
        const event = this.eventRepository.create(createEventDto);
        return await this.eventRepository.save(event);
    }
    /**
     * Listar eventos con filtros
     */
    async findAll(filters) {
        const where = {};
        if (filters?.tipo) {
            where.tipoActividad = filters.tipo;
        }
        if (filters?.estado) {
            where.estado = filters.estado;
        }
        if (filters?.desde && filters?.hasta) {
            where.fechaInicio = (0, typeorm_2.Between)(new Date(filters.desde), new Date(filters.hasta));
        }
        else if (filters?.desde) {
            where.fechaInicio = (0, typeorm_2.MoreThanOrEqual)(new Date(filters.desde));
        }
        return await this.eventRepository.find({
            where,
            order: { fechaInicio: 'ASC' },
            relations: ['participantes', 'participantes.user']
        });
    }
    /**
     * Obtener evento por ID
     */
    async findOne(id) {
        const event = await this.eventRepository.findOne({
            where: { id },
            relations: ['participantes', 'participantes.user']
        });
        if (!event) {
            throw new common_1.NotFoundException(`Evento con ID ${id} no encontrado`);
        }
        return event;
    }
    /**
     * Obtener evento por slug
     */
    async findBySlug(slug) {
        const event = await this.eventRepository.findOne({
            where: { slug },
            relations: ['participantes', 'participantes.user']
        });
        if (!event) {
            throw new common_1.NotFoundException(`Evento con slug "${slug}" no encontrado`);
        }
        return event;
    }
    /**
     * Actualizar evento (solo admin/junta)
     */
    async update(id, updateEventDto) {
        const event = await this.findOne(id);
        if (updateEventDto.slug && updateEventDto.slug !== event.slug) {
            const existingEvent = await this.eventRepository.findOne({
                where: { slug: updateEventDto.slug }
            });
            if (existingEvent) {
                throw new common_1.BadRequestException(`El slug "${updateEventDto.slug}" ya está en uso`);
            }
        }
        Object.assign(event, updateEventDto);
        return await this.eventRepository.save(event);
    }
    /**
     * Eliminar evento (solo admin/junta)
     */
    async remove(id) {
        const event = await this.findOne(id);
        await this.eventRepository.remove(event);
    }
    /**
     * Inscribir miembro a evento
     */
    async registerParticipant(eventId, userId, registerDto) {
        const event = await this.findOne(eventId);
        if (event.estado !== event_entity_1.EventStatus.PUBLICADO) {
            throw new common_1.BadRequestException('Este evento no está disponible para inscripciones');
        }
        if (new Date(event.fechaInicio) < new Date()) {
            throw new common_1.BadRequestException('No puedes inscribirte a un evento que ya inició');
        }
        const existingParticipant = await this.participantRepository.findOne({
            where: { eventId, userId }
        });
        if (existingParticipant) {
            throw new common_1.BadRequestException('Ya estás inscrito en este evento');
        }
        const participant = this.participantRepository.create({
            eventId,
            userId,
            fuente: registerDto.fuente || event_participant_entity_1.RegistrationSource.WEB,
            notas: registerDto.notas,
            estado: event_participant_entity_1.ParticipantStatus.REGISTRADO
        });
        return await this.participantRepository.save(participant);
    }
    /**
     * Cancelar inscripción
     */
    async cancelRegistration(eventId, userId) {
        const participant = await this.participantRepository.findOne({
            where: { eventId, userId }
        });
        if (!participant) {
            throw new common_1.NotFoundException('No estás inscrito en este evento');
        }
        await this.participantRepository.remove(participant);
    }
    /**
     * Actualizar estado de participación (solo admin)
     */
    async updateParticipantStatus(updateDto) {
        const participant = await this.participantRepository.findOne({
            where: { id: updateDto.participantId },
            relations: ['event', 'user']
        });
        if (!participant) {
            throw new common_1.NotFoundException(`Participante ${updateDto.participantId} no encontrado`);
        }
        participant.estado = updateDto.estado;
        return await this.participantRepository.save(participant);
    }
    /**
     * Obtener participantes de un evento
     */
    async getEventParticipants(eventId) {
        return await this.participantRepository.find({
            where: { eventId },
            relations: ['user'],
            order: { fechaRegistro: 'DESC' }
        });
    }
    /**
     * Verificar si un usuario está inscrito
     */
    async isUserRegistered(eventId, userId) {
        const count = await this.participantRepository.count({
            where: { eventId, userId }
        });
        return count > 0;
    }
    /**
     * Obtener estadísticas de un evento
     */
    async getEventStats(eventId) {
        const participants = await this.participantRepository.find({
            where: { eventId }
        });
        return {
            totalRegistrados: participants.length,
            confirmados: participants.filter(p => p.estado === event_participant_entity_1.ParticipantStatus.CONFIRMADO).length,
            asistieron: participants.filter(p => p.estado === event_participant_entity_1.ParticipantStatus.ASISTIO).length,
            noAsistieron: participants.filter(p => p.estado === event_participant_entity_1.ParticipantStatus.NO_ASISTIO).length
        };
    }
    /**
     * Ranking de asistencia anual
     * Calcula puntos, eventos y kilometraje por miembro
     */
    async getRankingAnual(year) {
        const targetYear = year || new Date().getFullYear();
        const startDate = new Date(targetYear, 0, 1);
        const endDate = new Date(targetYear, 11, 31, 23, 59, 59);
        const participantes = await this.participantRepository.find({
            where: {
                estado: event_participant_entity_1.ParticipantStatus.ASISTIO
            },
            relations: ['event', 'user']
        });
        const participantesYear = participantes.filter(p => {
            const fechaEvento = new Date(p.event.fechaInicio);
            return fechaEvento >= startDate && fechaEvento <= endDate;
        });
        const rankingMap = new Map();
        participantesYear.forEach(p => {
            const userId = p.userId;
            if (!rankingMap.has(userId)) {
                rankingMap.set(userId, {
                    userId,
                    nombre: p.user.nombreCompleto,
                    email: p.user.correo,
                    totalEventos: 0,
                    totalPuntos: 0,
                    totalKilometros: 0,
                    eventos: []
                });
            }
            const userStats = rankingMap.get(userId);
            const puntos = event_points_rules_1.EventPointsRules.getPoints(p.event.tipoActividad);
            userStats.totalEventos++;
            userStats.totalPuntos += puntos;
            userStats.totalKilometros += p.event.kilometraje;
            userStats.eventos.push({
                titulo: p.event.titulo,
                tipo: p.event.tipoActividad,
                fecha: p.event.fechaInicio,
                puntos,
                kilometraje: p.event.kilometraje
            });
        });
        const ranking = Array.from(rankingMap.values())
            .sort((a, b) => {
            if (b.totalPuntos !== a.totalPuntos) {
                return b.totalPuntos - a.totalPuntos;
            }
            return b.totalKilometros - a.totalKilometros;
        })
            .map((item, index) => ({
            posicion: index + 1,
            ...item,
            medalla: event_points_rules_1.EventPointsRules.getMedal(item.totalPuntos),
            colorMedalla: event_points_rules_1.EventPointsRules.getMedalColor(item.totalPuntos)
        }));
        return ranking;
    }
    /**
     * Estadísticas de un miembro específico
     */
    async getMemberStats(userId, year) {
        const targetYear = year || new Date().getFullYear();
        const startDate = new Date(targetYear, 0, 1);
        const endDate = new Date(targetYear, 11, 31, 23, 59, 59);
        const participaciones = await this.participantRepository.find({
            where: {
                userId,
                estado: event_participant_entity_1.ParticipantStatus.ASISTIO
            },
            relations: ['event']
        });
        const participacionesYear = participaciones.filter(p => {
            const fechaEvento = new Date(p.event.fechaInicio);
            return fechaEvento >= startDate && fechaEvento <= endDate;
        });
        let totalPuntos = 0;
        let totalKilometros = 0;
        const eventosPorTipo = {};
        participacionesYear.forEach(p => {
            totalPuntos += event_points_rules_1.EventPointsRules.getPoints(p.event.tipoActividad);
            totalKilometros += p.event.kilometraje;
            const tipo = p.event.tipoActividad;
            eventosPorTipo[tipo] = (eventosPorTipo[tipo] || 0) + 1;
        });
        return {
            year: targetYear,
            totalEventos: participacionesYear.length,
            totalPuntos,
            totalKilometros,
            medalla: event_points_rules_1.EventPointsRules.getMedal(totalPuntos),
            colorMedalla: event_points_rules_1.EventPointsRules.getMedalColor(totalPuntos),
            eventosPorTipo,
            ultimosEventos: participacionesYear
                .slice(0, 5)
                .map(p => ({
                titulo: p.event.titulo,
                fecha: p.event.fechaInicio,
                tipo: p.event.tipoActividad,
                kilometraje: p.event.kilometraje
            }))
        };
    }
};
exports.EventsService = EventsService;
exports.EventsService = EventsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(event_entity_1.Event)),
    __param(1, (0, typeorm_1.InjectRepository)(event_participant_entity_1.EventParticipant)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], EventsService);
//# sourceMappingURL=events.service.js.map