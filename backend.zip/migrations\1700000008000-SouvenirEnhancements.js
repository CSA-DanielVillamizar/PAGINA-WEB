"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SouvenirEnhancements1700000008000 = void 0;
const typeorm_1 = require("typeorm");
class SouvenirEnhancements1700000008000 {
    async up(queryRunner) {
        await queryRunner.addColumn('souvenirs', new typeorm_1.TableColumn({
            name: 'inventory',
            type: 'jsonb',
            isNullable: true,
            comment: 'Inventario detallado: quantity, reserved, available, lastRestockDate'
        }));
        await queryRunner.addColumn('souvenirs', new typeorm_1.TableColumn({
            name: 'transactions',
            type: 'jsonb',
            default: "'[]'",
            comment: 'Historial de transacciones: date, type, quantity, userId, notes'
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('souvenirs', 'transactions');
        await queryRunner.dropColumn('souvenirs', 'inventory');
    }
}
exports.SouvenirEnhancements1700000008000 = SouvenirEnhancements1700000008000;
//# sourceMappingURL=1700000008000-SouvenirEnhancements.js.map