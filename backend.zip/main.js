"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const core_1 = require("@nestjs/core");
const app_module_1 = require("./app.module");
const common_1 = require("@nestjs/common");
// Swagger se cargará sólo si ENABLE_SWAGGER=1 para acelerar cold start.
const database_provider_1 = require("./database/database.provider");
const logger = new common_1.Logger('Bootstrap');
/**
 * Arranca la aplicación NestJS con reintentos y añade diagnóstico explícito
 * de la conexión a PostgreSQL usando el DataSource una vez levantado el servidor.
 * Esto permite capturar errores de conexión (autenticación, SSL, DB inexistente)
 * incluso cuando TypeORM hace fallar silenciosamente el bootstrap.
 */
async function bootstrap(retry = 0) {
    try {
        logger.log('[BOOT] start env=' + (process.env.NODE_ENV || 'undefined') + ' port=' + (process.env.PORT || 'unset'));
        logger.log('[BOOT] flags disable_db=' + (process.env.DISABLE_DB || '0') + ' swagger=' + (process.env.ENABLE_SWAGGER || '0'));
        logger.log('[BOOT] creating app');
        const app = await core_1.NestFactory.create(app_module_1.AppModule, {
            bufferLogs: true,
            logger: ['error', 'warn', 'log', 'debug', 'verbose']
        });
        app.useLogger(logger);
        logger.log('[BOOT] app created');
        logger.log('[BOOT] validation pipe');
        app.useGlobalPipes(new common_1.ValidationPipe({
            whitelist: true,
            transform: true,
            forbidNonWhitelisted: true
        }));
        logger.log('[BOOT] validation ready');
        logger.log('[BOOT] api prefix /api');
        app.setGlobalPrefix('api');
        logger.log('[BOOT] prefix ready');
        logger.log('[BOOT] cors setup');
        app.enableCors({
            origin: process.env.FRONTEND_URL || 'http://localhost:5173',
            credentials: true
        });
        logger.log('[BOOT] cors ready');
        if (process.env.ENABLE_SWAGGER === '1') {
            logger.log('[BOOT] swagger enabled');
            const { SwaggerModule, DocumentBuilder } = await Promise.resolve().then(() => __importStar(require('@nestjs/swagger')));
            const config = new DocumentBuilder().setTitle('LAMA API').setVersion('1.0').addBearerAuth().build();
            const document = SwaggerModule.createDocument(app, config);
            SwaggerModule.setup('api/docs', app, document);
            logger.log('[BOOT] swagger ready');
        }
        else {
            logger.log('[BOOT] swagger skipped');
        }
        logger.log('[BOOT] health endpoint');
        const expressInstance = app.getHttpAdapter().getInstance();
        if (expressInstance?.get) {
            expressInstance.get('/health', (_req, res) => {
                res.json({ status: 'ok', service: 'lama-backend', uptime: process.uptime() });
            });
            logger.log('[BOOT] health ready');
        }
        else {
            logger.warn('[BOOT] health not configured');
        }
        logger.log('[BOOT] listen');
        const port = process.env.PORT || '8080';
        await app.listen(port, '0.0.0.0');
        logger.log('[BOOT] listening port=' + port);
        // Paso 8: Inicialización LAZY de PostgreSQL en background (no bloquea startup)
        if (process.env.DISABLE_DB !== '1') {
            logger.log('[DB LazyInit] trigger');
            void (async () => {
                logger.log('[DB LazyInit] start');
                const start = Date.now();
                await (0, database_provider_1.ensureDatabaseInitialized)();
                const elapsed = Date.now() - start;
                const status = (0, database_provider_1.getDatabaseStatus)();
                if (status === 'connected') {
                    logger.log(`[DB LazyInit] connected in ${elapsed}ms`);
                }
                else if (status === 'error') {
                    const err = (0, database_provider_1.getDatabaseError)();
                    logger.error(`[DB LazyInit] error: ${err?.message}`);
                }
                else {
                    logger.warn('[DB LazyInit] pending');
                }
            })();
        }
        else {
            logger.log('[DB LazyInit] skipped (disabled)');
        }
        logger.log('[BOOT] ready url=http://0.0.0.0:' + port);
    }
    catch (err) {
        logger.error('=== ERROR FATAL DURANTE BOOTSTRAP ===');
        logger.error(`Intento: ${retry + 1}/5`);
        logger.error(`Tipo de error: ${err?.constructor?.name || 'Unknown'}`);
        logger.error(`Mensaje: ${err?.message || 'No message'}`);
        if (err?.stack) {
            logger.error('Stack trace completo:');
            logger.error(err.stack);
        }
        try {
            logger.error('Propiedades del error:', JSON.stringify(err, Object.getOwnPropertyNames(err), 2));
        }
        catch {
            logger.error('No se pudo serializar el error');
        }
        logger.error('=== FIN ERROR ===');
        if (retry < 4) {
            const delayMs = 3000 * (retry + 1);
            logger.warn(`Reintentando bootstrap en ${delayMs}ms...`);
            await new Promise(res => setTimeout(res, delayMs));
            return bootstrap(retry + 1);
        }
        logger.error('Falló el inicio después de 5 intentos. Proceso abortado.');
        process.exit(1);
    }
}
bootstrap().catch(err => {
    console.error('=== BOOTSTRAP CRASHED COMPLETAMENTE ===');
    console.error('Error:', err);
    if (err?.stack) {
        console.error('Stack:', err.stack);
    }
    process.exit(1);
});
//# sourceMappingURL=main.js.map